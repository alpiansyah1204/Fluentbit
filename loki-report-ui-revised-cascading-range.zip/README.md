# Loki Report UI - Revised

## Perubahan utama
### 1. Report PDF memakai custom time range
Halaman **Laporan Log** sekarang tidak lagi bergantung pada `input type=month`.

Anda dapat menentukan:
- tanggal + jam START
- tanggal + jam END
- Quick Range 1 jam / 24 jam / 7 hari / 30 hari / 90 hari
- seluruh filter label
- text search

PDF sekarang berisi **record log aktual** pada range tersebut, bukan hanya total log dan 20 contoh log.

### 2. Cascading filter di semua halaman
Semua dropdown label saling membatasi berdasarkan pilihan aktif lainnya.

Contoh:
- pilih `app_group = wac`
- dropdown `os` hanya mengambil nilai OS yang memang ada pada stream OS logs dengan `app_group=wac`
- jika nilai OS sebelumnya menjadi tidak valid, UI otomatis mengosongkannya.

Ini berlaku di:
- Pencarian Log
- Laporan Log

Endpoint dropdown memakai selector Loki dengan filter aktif dan mengecualikan heartbeat.

### 3. Loki
Default tetap:
`http://192.168.114.75:3100`

Tidak mengubah konfigurasi Loki/Nginx.

## PDF dan batas record
PDF mengambil halaman-halaman log sampai range habis atau mencapai:
`REPORT_MAX_LOG_LINES=50000`

Jika batas tercapai, PDF menampilkan warning sehingga pengguna tahu bahwa hasil belum lengkap. Untuk laporan lengkap gunakan range/filter yang lebih sempit atau naikkan `REPORT_MAX_LOG_LINES`.

## Install/update
Copy project ke `/opt/loki-report-ui`, lalu:
```bash
source venv/bin/activate
pip install -r requirements.txt
python -m py_compile app.py
systemctl restart loki-report-ui
systemctl status loki-report-ui --no-pager
```

Jika menggunakan `.env`, contoh:
```env
LOKI_URL=http://192.168.114.75:3100
APP_PORT=8080
MAX_LOG_LINES=2000
REPORT_MAX_LOG_LINES=50000
LOKI_TIMEOUT=60
```

## Test
```bash
curl http://192.168.114.75:3100/ready
curl http://127.0.0.1:8080/api/health
```
