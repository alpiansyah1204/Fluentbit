import time
from datetime import datetime,timedelta,timezone
from flask import Flask,render_template,request,jsonify,send_file
from config import Config
import loki_client,report_generator

app=Flask(__name__)
app.config.from_object(Config)

def to_ns(dt): return int(dt.timestamp()*1e9)

def _parse_iso(s):
    if not s:return None
    s=s.strip()
    if s.endswith("Z"):s=s[:-1]+"+00:00"
    x=datetime.fromisoformat(s)
    if x.tzinfo is None:x=x.replace(tzinfo=timezone.utc)
    return x.astimezone(timezone.utc)

def parse_range(args):
    start_str=args.get("start");end_str=args.get("end");quick=args.get("range")
    if start_str and end_str:
        start=_parse_iso(start_str);end=_parse_iso(end_str)
        if not start or not end or start>=end: raise ValueError("Rentang waktu tidak valid.")
        return start,end
    now=datetime.now(timezone.utc)
    mapping={"1h":timedelta(hours=1),"6h":timedelta(hours=6),
             "24h":timedelta(hours=24),"7d":timedelta(days=7),
             "30d":timedelta(days=30),"90d":timedelta(days=90)}
    return now-mapping.get(quick,timedelta(days=30)),now

def filters_from(args,exclude=None):
    return {label:args.get(label,"").strip() for label in Config.LOKI_LABELS
            if label!=exclude}

@app.route("/")
def index():return render_template("index.html",labels=Config.LOKI_LABELS,config=Config)

@app.route("/report")
def report_page():return render_template("report.html",labels=Config.LOKI_LABELS,config=Config)

@app.route("/api/health")
def health():
    ok=loki_client.check_connection()
    return jsonify({"loki_connected":ok,"loki_url":Config.LOKI_URL})

@app.route("/api/label-values/<label_name>")
def api_label_values(label_name):
    if label_name not in Config.LOKI_LABELS:return jsonify({"error":"label tidak dikenal"}),400
    try:
        filters=filters_from(request.args,exclude=label_name)
        values=loki_client.get_label_values(label_name,filters)
        return jsonify({"label":label_name,"values":values})
    except loki_client.LokiError as e:return jsonify({"error":str(e)}),502

def _filters_from_request(args):
    return {label:args.get(label,"").strip() for label in Config.LOKI_LABELS}

@app.route("/api/search")
def api_search():
    filters=_filters_from_request(request.args);qtext=request.args.get("q","").strip()
    try:start,end=parse_range(request.args)
    except ValueError as e:return jsonify({"error":str(e)}),400
    query=loki_client.build_logql(filters,qtext)
    try:lines=loki_client.query_range(query,to_ns(start),to_ns(end))
    except loki_client.LokiError as e:return jsonify({"error":str(e)}),502
    return jsonify({"query":query,"count":len(lines),"start":start.isoformat(),
                    "end":end.isoformat(),"lines":lines[:Config.MAX_LOG_LINES]})

@app.route("/api/export/csv")
def export_csv():
    filters=_filters_from_request(request.args);qtext=request.args.get("q","").strip()
    try:start,end=parse_range(request.args)
    except ValueError as e:return jsonify({"error":str(e)}),400
    query=loki_client.build_logql(filters,qtext)
    try:lines=loki_client.query_range_all(query,to_ns(start),to_ns(end))
    except loki_client.LokiError as e:return jsonify({"error":str(e)}),502
    buf=report_generator.logs_to_csv(lines[0])
    return send_file(buf,mimetype="text/csv",as_attachment=True,
                     download_name=f"logs_{start.strftime('%Y%m%d')}_{end.strftime('%Y%m%d')}.csv")

@app.route("/api/report/monthly-pdf")
def report_pdf():
    filters=_filters_from_request(request.args);qtext=request.args.get("q","").strip()
    try:start,end=parse_range(request.args)
    except ValueError as e:return jsonify({"error":str(e)}),400
    query=loki_client.build_logql(filters,qtext)
    try:
        lines,truncated=loki_client.query_range_all(query,to_ns(start),to_ns(end),
                                                     page_limit=min(Config.MAX_LOG_LINES,5000),
                                                     max_lines=Config.REPORT_MAX_LOG_LINES)
    except loki_client.LokiError as e:return jsonify({"error":str(e)}),502
    period=f"{start.strftime('%Y-%m-%d %H:%M:%S %Z')} s/d {end.strftime('%Y-%m-%d %H:%M:%S %Z')}"
    pdf=report_generator.build_log_pdf("Laporan Log OS",filters,period,lines,truncated,
                                       Config.REPORT_MAX_LOG_LINES)
    return send_file(pdf,mimetype="application/pdf",as_attachment=True,
                     download_name=f"laporan_log_{start.strftime('%Y%m%d_%H%M')}_{end.strftime('%Y%m%d_%H%M')}.pdf")

@app.route("/api/report/monthly-chart-data")
def report_chart():
    try:start,end=parse_range(request.args)
    except ValueError as e:return jsonify({"error":str(e)}),400
    filters=_filters_from_request(request.args);q=loki_client.build_logql(filters)
    try:series=loki_client.query_count_over_time(query=q,start_ns=to_ns(start),end_ns=to_ns(end),step_seconds=86400)
    except loki_client.LokiError as e:return jsonify({"error":str(e)}),502
    daily=report_generator._daily_counts_from_series(series)
    return jsonify({"labels":list(daily),"values":list(daily.values()),"total":sum(daily.values()),
                    "start":start.isoformat(),"end":end.isoformat()})

if __name__=="__main__":app.run(host=Config.APP_HOST,port=Config.APP_PORT,debug=False)
