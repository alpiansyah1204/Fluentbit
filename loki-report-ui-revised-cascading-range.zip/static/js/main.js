async function fetchJSON(url){const res=await fetch(url);let data={};try{data=await res.json()}catch{}if(!res.ok)throw new Error(data.error||data.message||"Terjadi kesalahan");return data}
function escapeHtml(s){const d=document.createElement("div");d.textContent=s??"";return d.innerHTML}
function localInputDate(d){const p=n=>String(n).padStart(2,"0");return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`}
async function checkStatus(){const el=document.getElementById("loki-status");if(!el)return;try{const d=await fetchJSON("/api/health");el.textContent=d.loki_connected?"✅ Terhubung ke Loki":"⚠️ Loki tidak siap";el.className="status "+(d.loki_connected?"ok":"error")}catch{el.textContent="⚠️ Gagal cek status";el.className="status error"}}

async function populateCascading(prefix){
 const selects=[...document.querySelectorAll(`select[id^="${prefix}-"]`)];
 const current={};selects.forEach(s=>current[s.name]=s.value);
 for(const sel of selects){
   const params=new URLSearchParams();
   // For this target, every OTHER active filter becomes a constraint.
   selects.forEach(other=>{if(other!==sel && other.value)params.set(other.name,other.value)});
   sel.disabled=true;
   try{
     const d=await fetchJSON(`/api/label-values/${encodeURIComponent(sel.name)}?${params}`);
     const old=current[sel.name];
     sel.innerHTML='<option value="">-- semua --</option>';
     (d.values||[]).forEach(v=>{const o=document.createElement("option");o.value=v;o.textContent=v;sel.appendChild(o)});
     if((d.values||[]).includes(old))sel.value=old;else if(old)sel.value="";
   }catch(e){console.warn("label",sel.name,e)}
   sel.disabled=false;
 }
}
function initCascading(prefix){
 const selects=[...document.querySelectorAll(`select[id^="${prefix}-"]`)];
 selects.forEach(s=>s.addEventListener("change",()=>populateCascading(prefix)));
 populateCascading(prefix);
}

function rangeParams(form,mode){
 const fd=new FormData(form),p=new URLSearchParams();
 for(const [k,v] of fd.entries())if(v)p.set(k,v);
 if(mode==="search" && fd.get("range")==="custom"){
   p.delete("range");
   p.set("start",new Date(document.getElementById("search-start").value).toISOString());
   p.set("end",new Date(document.getElementById("search-end").value).toISOString());
 }
 return p;
}
function renderLogs(lines,tbody,table,empty){
 tbody.innerHTML="";
 if(!lines.length){table.style.display="none";empty.style.display="block";return}
 table.style.display="table";empty.style.display="none";
 for(const item of lines){
   const tr=document.createElement("tr"),ts=new Date(item.timestamp_ns/1e6).toLocaleString("id-ID");
   const lh=Object.entries(item.labels||{}).map(([k,v])=>`<span class="badge">${escapeHtml(k)}=${escapeHtml(v)}</span>`).join("");
   tr.innerHTML=`<td class="ts">${ts}</td><td>${lh}</td><td class="line">${escapeHtml(item.line)}</td>`;
   tbody.appendChild(tr);
 }
}

function initSearchPage(){
 const form=document.getElementById("search-form");if(!form)return;
 initCascading("filter");const table=document.getElementById("result-table"),tbody=document.getElementById("result-body"),empty=document.getElementById("empty-state"),info=document.getElementById("search-info");
 const range=document.getElementById("range"),custom=document.getElementById("custom-range-search");
 range.addEventListener("change",()=>custom.classList.toggle("hidden",range.value!=="custom"));
 async function search(){
  info.textContent="Mencari log aktual...";
  try{const p=rangeParams(form,"search"),d=await fetchJSON(`/api/search?${p}`);
   renderLogs(d.lines,tbody,table,empty);info.textContent=`${d.count.toLocaleString("id-ID")} record dikembalikan • ${d.start} → ${d.end}`;
  }catch(e){info.textContent="Error: "+e.message}
 }
 form.addEventListener("submit",e=>{e.preventDefault();search()});
 document.getElementById("btn-export-csv").addEventListener("click",()=>{const p=rangeParams(form,"search");location.href=`/api/export/csv?${p}`});
}

function setReportRange(kind){
 const end=new Date(),start=new Date(end);
 const m={ "1h":3600000,"24h":86400000,"7d":7*86400000,"30d":30*86400000,"90d":90*86400000};
 start.setTime(end.getTime()-m[kind]);document.getElementById("report-start").value=localInputDate(start);document.getElementById("report-end").value=localInputDate(end);
}
function initReportPage(){
 const form=document.getElementById("report-form");if(!form)return;
 initCascading("rfilter");setReportRange("30d");
 let chart=null;const info=document.getElementById("report-info");
 document.querySelectorAll(".quick-range").forEach(b=>b.addEventListener("click",()=>{setReportRange(b.dataset.range);loadReportChart()}));
 function params(){const p=new URLSearchParams(new FormData(form));p.delete("range");p.set("start",new Date(form.start.value).toISOString());p.set("end",new Date(form.end.value).toISOString());return p}
 async function loadReportChart(){
  info.textContent="Memuat preview...";
  try{const d=await fetchJSON(`/api/report/monthly-chart-data?${params()}`);const ctx=document.getElementById("dailyChart");
   if(chart)chart.destroy();chart=new Chart(ctx,{type:"bar",data:{labels:d.labels,datasets:[{label:"Jumlah Log per Hari",data:d.values,backgroundColor:"#2563eb"}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}});
   info.textContent=`Periode ${d.start} → ${d.end} • ${d.total.toLocaleString("id-ID")} log terhitung`;
   // Preview actual records too.
   const s=await fetchJSON(`/api/search?${params()}`);const area=document.getElementById("report-preview");
   area.innerHTML=`<h3>Preview Log (${s.count.toLocaleString("id-ID")} record)</h3><div class="scroll-preview"><table class="log-table"><thead><tr><th>Waktu</th><th>Source</th><th>Host</th><th>Log</th></tr></thead><tbody>${s.lines.slice(0,200).map(x=>`<tr><td class="ts">${new Date(x.timestamp_ns/1e6).toLocaleString("id-ID")}</td><td>${escapeHtml(x.labels?.source)}</td><td>${escapeHtml(x.labels?.host)}</td><td class="line">${escapeHtml(x.line)}</td></tr>`).join("")}</tbody></table></div>`;
  }catch(e){info.textContent="Error: "+e.message}
 }
 form.addEventListener("submit",e=>{e.preventDefault();loadReportChart()});
 document.getElementById("btn-download-pdf").addEventListener("click",()=>{const p=params();location.href=`/api/report/monthly-pdf?${p}`});
 loadReportChart();
}
document.addEventListener("DOMContentLoaded",()=>{checkStatus();initSearchPage();initReportPage()});