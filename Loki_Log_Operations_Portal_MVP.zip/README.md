# Loki Log Operations Portal MVP

Fokus utama aplikasi ini adalah **mengambil log langsung**, bukan menghitung total log.

## Alur utama
1. Server ditemukan dari heartbeat 30 hari.
2. Pilih satu server.
3. Web membentuk selector:
```logql
{job="os-logs",host="SERVER01",source!="heartbeat"}
```
4. `query_range` Loki mengambil record log aktual.
5. Hasil ditampilkan sebagai tabel.
6. Source, severity, text search dan time range dapat difilter.
7. Hasil dapat diekspor CSV.
8. LogQL Console tersedia untuk query bebas.

Heartbeat tidak ditampilkan pada All OS Logs.

## Install
```bash
cd /data/log_management
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 -m py_compile app.py
python3 app.py
```
Akses `http://SERVER_IP:8500`.

Default Loki: `http://192.168.114.75` (Nginx :80).

## Test
```bash
curl http://192.168.114.75/ready
curl http://127.0.0.1:8500/
tail -f logs/app.log
```

## Catatan kapasitas
"Semua log" berarti semua record yang cocok dengan server dan time range, tetapi UI mengambilnya secara bounded (`limit`) agar tidak menarik jutaan record sekaligus. Untuk dataset besar, persempit time range atau gunakan export dengan range yang masuk akal.
