from fastapi import FastAPI,Request,HTTPException,Query
from fastapi.responses import HTMLResponse,StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel,Field
from datetime import datetime,timedelta,timezone
from pathlib import Path
import requests,os,re,csv,io,time,logging

BASE=Path(__file__).resolve().parent
LOKI=os.getenv("LOKI_URL","http://192.168.114.75").rstrip("/")
PORT=int(os.getenv("APP_PORT","8500")); TIMEOUT=int(os.getenv("LOKI_TIMEOUT","60"))
logging.basicConfig(filename=str(BASE/"logs/app.log"),level=logging.INFO,
 format="%(asctime)s %(levelname)s %(message)s")
app=FastAPI(title="Loki Log Operations Portal",version="2.0")
app.mount("/static",StaticFiles(directory=str(BASE/"static")),name="static")
tpl=Jinja2Templates(directory=str(BASE/"templates"))

class LogReq(BaseModel):
 host:str=Field(min_length=1,max_length=255);ip:str=""
 start:str;end:str;source:str="All";search:str="";severity:str="All"
 limit:int=Field(1000,ge=1,le=10000)
class QueryReq(BaseModel):
 query:str=Field(min_length=1,max_length=30000);query_type:str="range"
 start:str="";end:str="";limit:int=Field(1000,ge=1,le=10000)

def dt(v,fb):
 if not v:return fb
 if v.endswith("Z"):v=v[:-1]+"+00:00"
 x=datetime.fromisoformat(v)
 return (x if x.tzinfo else x.replace(tzinfo=timezone.utc)).astimezone(timezone.utc)
def ns(x):return str(int(x.timestamp()*1e9))
def esc(v):return v.replace("\\","\\\\").replace('"','\\"')
def get(path,params):
 t=time.perf_counter()
 try:
  q=requests.get(LOKI+path,params=params,timeout=TIMEOUT)
  e=time.perf_counter()-t; data=q.json()
  if not q.ok:raise HTTPException(502,detail={"message":"Loki HTTP error","status":q.status_code,"response":data})
  return data,e
 except HTTPException:raise
 except Exception as ex:
  raise HTTPException(502,detail={"message":"Cannot connect to Loki","error":str(ex),"url":LOKI+path})
def stream_rows(data):
 out=[]
 for x in data.get("data",{}).get("result",[]):
  for v in x.get("values",[]):
   if len(v)>1:
    z=dict(x.get("stream",{}));z["timestamp_ns"]=v[0];z["log"]=v[1];out.append(z)
 return out
def metric_rows(data):
 out=[]
 for x in data.get("data",{}).get("result",[]):
  z=dict(x.get("metric",{}))
  if "value" in x:z["timestamp"]=x["value"][0];z["value"]=x["value"][1]
  out.append(z)
 return out
def server_selector(host,ip=""):
 q='{job="os-logs",host="'+esc(host)+'"'
 if ip:q+=',ip="'+esc(ip)+'"'
 return q+',source!="heartbeat"}'
def filters(q,source,search,severity):
 if source!="All":q=q[:-1]+',source="'+esc(source)+'"}'
 if search:q+=' |~ "(?i)'+search.replace('"','\\"')+'"'
 p={"critical":"(critical|crit|emerg|alert)","error":"(error|err)",
    "warning":"(warning|warn)","failure":"(failed|failure|fatal)"}
 if severity!="All":q+=' |~ "(?i)'+p.get(severity,"")+'"'
 return q

@app.get("/",response_class=HTMLResponse)
def home(request:Request):return tpl.TemplateResponse("index.html",{"request":request,"loki":LOKI})
@app.get("/api/health")
def health():
 t=time.perf_counter()
 try:
  x=requests.get(LOKI+"/ready",timeout=10)
  return {"ok":x.ok,"status":x.status_code,"response":x.text.strip(),"latency_ms":round((time.perf_counter()-t)*1000,1)}
 except Exception as e:return {"ok":False,"response":str(e),"latency_ms":round((time.perf_counter()-t)*1000,1)}
@app.get("/api/servers")
def servers():
 q='sum by (host,ip,os,environment,app_group,server_role,site) (count_over_time({job="os-logs",source="heartbeat"}[30d]))'
 d,e=get("/loki/api/v1/query",{"query":q});u={}
 for x in metric_rows(d):
  if x.get("host"):u[(x["host"],x.get("ip",""))]={k:x.get(k,"") for k in ["host","ip","os","environment","app_group","server_role","site"]}
 return {"servers":sorted(u.values(),key=lambda x:(x["site"],x["app_group"],x["host"])),"query":q}
@app.get("/api/server/{host}/sources")
def sources(host:str):
 q=f'sum by (source) (count_over_time({server_selector(host)}[30d]))';d,e=get("/loki/api/v1/query",{"query":q})
 return {"sources":metric_rows(d)}
@app.post("/api/server/logs")
def server_logs(x:LogReq):
 s=dt(x.start,datetime.now(timezone.utc)-timedelta(hours=1));e=dt(x.end,datetime.now(timezone.utc))
 if s>=e:raise HTTPException(400,"Start must be before end")
 q=filters(server_selector(x.host,x.ip),x.source,x.search,x.severity)
 d,t=get("/loki/api/v1/query_range",{"query":q,"start":ns(s),"end":ns(e),"limit":x.limit,"direction":"backward"})
 rows=stream_rows(d);return {"query":q,"count":len(rows),"elapsed_ms":round(t*1000,1),"rows":rows}
@app.post("/api/query")
def query(x:QueryReq):
 if x.query_type=="instant":
  d,t=get("/loki/api/v1/query",{"query":x.query});return {"query":x.query,"elapsed_ms":round(t*1000,1),"rows":metric_rows(d),"raw":d}
 e=dt(x.end,datetime.now(timezone.utc));s=dt(x.start,e-timedelta(hours=1))
 d,t=get("/loki/api/v1/query_range",{"query":x.query,"start":ns(s),"end":ns(e),"limit":x.limit,"direction":"backward"})
 return {"query":x.query,"count":len(stream_rows(d)),"elapsed_ms":round(t*1000,1),"rows":stream_rows(d),"raw":d}
@app.get("/api/labels")
def labels():
 d,e=get("/loki/api/v1/labels",{});return {"labels":d.get("data",[])}
@app.get("/api/labels/{label}/values")
def values(label:str):
 if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*",label):raise HTTPException(400,"Invalid label")
 d,e=get(f"/loki/api/v1/label/{label}/values",{});return {"values":d.get("data",[])}
@app.get("/api/export/server-logs")
def export(host:str=Query(...),ip:str="",start:str=Query(...),end:str=Query(...),source:str="All",search:str="",severity:str="All",limit:int=100000):
 s=dt(start,datetime.now(timezone.utc)-timedelta(hours=1));e=dt(end,datetime.now(timezone.utc))
 q=filters(server_selector(host,ip),source,search,severity);d,_=get("/loki/api/v1/query_range",{"query":q,"start":ns(s),"end":ns(e),"limit":limit,"direction":"backward"})
 rows=stream_rows(d);fields=["timestamp_ns","host","ip","os","environment","app_group","server_role","site","source","log"]
 f=io.StringIO();w=csv.DictWriter(f,fieldnames=fields,extrasaction="ignore");w.writeheader();w.writerows(rows)
 name=re.sub(r"[^A-Za-z0-9_.-]","_",host)+"_os_logs.csv"
 return StreamingResponse(iter([f.getvalue().encode()]),media_type="text/csv",headers={"Content-Disposition":f'attachment; filename="{name}"'})
if __name__=="__main__":
 import uvicorn;uvicorn.run("app:app",host="0.0.0.0",port=PORT)
