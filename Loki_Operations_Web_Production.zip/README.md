# Loki Operations Web

Production-oriented Flask web application for operational OS log management with Loki.

## Main capabilities

- Operations Dashboard
- Actual OS Log Explorer
- Cascading filters: app_group, environment, host, IP, OS, server_role, service_name, site, source
- Cascading filters are bidirectional: choosing `app_group=wac` restricts OS to values that actually exist with wac
- Custom start/end date-time
- Quick ranges: 1h, 24h, 7d, 30d, 90d
- Actual log records, not only counts
- Load More pagination
- CSV export
- PDF reporting containing actual log rows
- Inventory from heartbeat
- Online/no-heartbeat status
- Read-only LogQL console
- Health diagnostics
- Security and heartbeat excluded from OS-log explorer/report by default

## Loki

Default:
`http://192.168.114.75:3100`

The installer does not modify an existing Nginx configuration.

## Deploy

```bash
cd /path/to/loki-report-ui
chmod +x deploy/install.sh
./deploy/install.sh
```

Then:

```bash
systemctl status loki-report-ui --no-pager
curl http://127.0.0.1:8080/api/health
```

Open:
`http://SERVER_IP:8080`

## Configuration

Edit `/opt/loki-report-ui/.env`:

```env
LOKI_URL=http://192.168.114.75:3100
MAX_LOG_LINES=5000
MAX_EXPORT_LINES=100000
REPORT_MAX_LINES=50000
```

Restart:

```bash
systemctl restart loki-report-ui
```

## Log query

For one server:

```logql
{job="os-logs",host="SERVER01",source!="heartbeat",source!="security"}
```

## Important

The PDF has a configurable safety limit (`REPORT_MAX_LINES`) because an unrestricted multi-month report can contain millions of rows and become an unusable PDF. The web explorer uses pagination so operators can continue with Load More.

For very large archival exports, CSV is recommended.
