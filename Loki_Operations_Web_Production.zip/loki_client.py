
import time, requests
from functools import lru_cache
from config import Config
class LokiError(Exception): pass
def base(): return Config.LOKI_URL.rstrip("/")
def _get(path,params=None,timeout=None):
    try:
        t=time.perf_counter()
        r=requests.get(base()+path,params=params or {},timeout=timeout or Config.LOKI_TIMEOUT)
        elapsed=(time.perf_counter()-t)*1000
        try: data=r.json()
        except Exception: data={"raw":r.text}
        if not r.ok: raise LokiError(f"Loki HTTP {r.status_code}: {data}")
        return data,elapsed
    except LokiError: raise
    except requests.RequestException as e: raise LokiError(f"Loki connection error: {e}")
def esc(v): return str(v).replace("\\","\\\\").replace('"','\\"')
def selector(filters=None, exclude_heartbeat=True):
    parts=['job="os-logs"']
    if exclude_heartbeat: parts += ['source!="heartbeat"','source!="security"']
    for k,v in (filters or {}).items():
        if v: parts.append(f'{k}="{esc(v)}"')
    return "{"+",".join(parts)+"}"
def build_logql(filters=None,text=""):
    q=selector(filters)
    if text:
        q += ' |= "'+text.replace("\\","\\\\").replace('"','\\"')+'"'
    return q
def query_range(query,start_ns,end_ns,limit=None,direction="backward"):
    d,e=_get("/loki/api/v1/query_range",{"query":query,"start":str(start_ns),"end":str(end_ns),
        "limit":int(limit or Config.MAX_LOG_LINES),"direction":direction})
    lines=[]
    for s in d.get("data",{}).get("result",[]):
        labels=s.get("stream",{})
        for ts,line in s.get("values",[]):
            lines.append({"timestamp_ns":int(ts),"line":line,"labels":labels})
    lines.sort(key=lambda x:x["timestamp_ns"],reverse=True)
    return lines,e
def series(match,start_ns,end_ns):
    d,e=_get("/loki/api/v1/series",{"match[]":match,"start":str(start_ns),"end":str(end_ns)})
    return d.get("data",[]),e
def metric(query,start_ns=None,end_ns=None):
    params={"query":query}
    if start_ns is not None: params["time"]=str(end_ns or start_ns)
    d,e=_get("/loki/api/v1/query",params)
    return d,e
def health():
    try:
        d,e=_get("/ready",{},10)
        return True,e,"ready"
    except LokiError as ex:
        return False,0,str(ex)
def label_values(label,match=None,start_ns=None,end_ns=None):
    params={}
    if match: params["match[]"]=match
    if start_ns is not None: params["start"]=str(start_ns)
    if end_ns is not None: params["end"]=str(end_ns)
    d,e=_get(f"/loki/api/v1/label/{label}/values",params)
    return sorted(d.get("data",[]),key=str.lower),e
