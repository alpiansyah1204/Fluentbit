"""
Loki API client.
"""
import csv
import io
import requests
from config import Config

class LokiError(Exception):
    pass

def _base_url():
    return Config.LOKI_URL.rstrip("/")

def _get(url, params=None, timeout=None):
    try:
        resp=requests.get(url, params=params or {}, timeout=timeout or Config.LOKI_TIMEOUT)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as e:
        raise LokiError(f"Gagal mengakses Loki: {e}")
    except ValueError as e:
        raise LokiError(f"Response Loki bukan JSON yang valid: {e}")

def _selector(filters: dict):
    parts=['job="os-logs"','source!="heartbeat"']
    for key,value in filters.items():
        if value:
            value=str(value).replace("\\","\\\\").replace('"','\\"')
            parts.append(f'{key}="{value}"')
    return "{"+", ".join(parts)+"}"

def get_label_values(label_name: str, filters=None):
    """Return label values constrained by the other active filters."""
    if filters is None: filters={}
    # Loki label-values supports match[] selectors. Exclude heartbeat so
    # cascading choices describe actual OS logs.
    match=_selector({k:v for k,v in filters.items() if k != label_name})
    url=f"{_base_url()}/loki/api/v1/label/{label_name}/values"
    data=_get(url, {"match[]": match})
    return sorted(data.get("data",[]), key=lambda x: str(x).lower())

def build_logql(filters: dict, freetext: str=""):
    q=_selector(filters)
    if not any(filters.values()):
        # Still keep the query scoped to this application's OS log streams.
        q='{job="os-logs",source!="heartbeat"}'
    if freetext:
        escaped=freetext.replace("\\","\\\\").replace('"','\\"')
        q += f' |= "{escaped}"'
    return q

def query_range(query, start_ns, end_ns, limit=None, direction="backward"):
    url=f"{_base_url()}/loki/api/v1/query_range"
    params={"query":query,"start":start_ns,"end":end_ns,
            "limit":limit or Config.MAX_LOG_LINES,"direction":direction}
    data=_get(url,params)
    lines=[]
    for stream in data.get("data",{}).get("result",[]):
        labels=stream.get("stream",{})
        for ts,line in stream.get("values",[]):
            lines.append({"timestamp_ns":int(ts),"line":line,"labels":labels})
    lines.sort(key=lambda x:x["timestamp_ns"],reverse=True)
    return lines

def query_range_all(query,start_ns,end_ns,page_limit=None,max_lines=None):
    """
    Fetch pages from Loki until the range is exhausted or MAX_REPORT_LINES
    is reached. A 1ns overlap is intentionally not used; this avoids
    repeatedly returning the same boundary record. If many records share the
    exact same timestamp, Loki's own limit can make that boundary ambiguous,
    so the returned 'truncated' flag is retained for the UI/PDF.
    """
    page_limit=page_limit or min(Config.MAX_LOG_LINES,5000)
    max_lines=max_lines or Config.REPORT_MAX_LOG_LINES
    all_lines=[]
    current_end=int(end_ns)
    start=int(start_ns)
    truncated=False
    while current_end > start and len(all_lines) < max_lines:
        take=min(page_limit,max_lines-len(all_lines))
        page=query_range(query,start,current_end,limit=take,direction="backward")
        if not page: break
        all_lines.extend(page)
        oldest=min(x["timestamp_ns"] for x in page)
        if len(page) < take:
            break
        # Move boundary backward by 1ns.
        if oldest <= start: break
        current_end=oldest-1
    if len(all_lines)>=max_lines:
        # There may be more records beyond the configured report cap.
        truncated=True
    # De-duplicate exact records returned by any boundary overlap.
    seen=set(); result=[]
    for x in all_lines:
        key=(x["timestamp_ns"],x["line"],tuple(sorted(x["labels"].items())))
        if key not in seen:
            seen.add(key); result.append(x)
    result.sort(key=lambda x:x["timestamp_ns"],reverse=True)
    return result,truncated

def query_count_over_time(query,start_ns,end_ns,step_seconds=3600):
    base_selector=query.split("|=")[0].strip()
    rq=f'count_over_time({base_selector}[{step_seconds}s])'
    data=_get(f"{_base_url()}/loki/api/v1/query_range",
              {"query":rq,"start":start_ns,"end":end_ns,"step":f"{step_seconds}s"})
    series=[]
    for result in data.get("data",{}).get("result",[]):
        points=[{"timestamp":int(float(ts)),"value":float(val)}
                for ts,val in result.get("values",[])]
        series.append({"labels":result.get("metric",{}),"points":points})
    return series

def check_connection():
    try:
        return requests.get(f"{_base_url()}/ready",timeout=5).status_code==200
    except requests.RequestException:
        return False
