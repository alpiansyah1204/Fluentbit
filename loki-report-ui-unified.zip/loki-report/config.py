import os
from dotenv import load_dotenv
load_dotenv()

class Config:
    LOKI_URL=os.environ.get("LOKI_URL","http://192.168.114.75:3100")
    LOKI_LABELS=[
        "app_group","environment","host","ip","job","os",
        "server_role","service_name","site","source"
    ]
    MAX_LOG_LINES=int(os.environ.get("MAX_LOG_LINES","2000"))
    REPORT_MAX_LOG_LINES=int(os.environ.get("REPORT_MAX_LOG_LINES","50000"))
    LOKI_TIMEOUT=int(os.environ.get("LOKI_TIMEOUT","60"))
    # Batas step (resolusi) grafik "log per waktu". Step dipilih otomatis
    # berdasarkan panjang rentang tanggal supaya grafik tidak kosong/error
    # saat user memilih rentang pendek (mis. 1 jam) maupun sangat panjang.
    CHART_MIN_STEP_SECONDS=int(os.environ.get("CHART_MIN_STEP_SECONDS","60"))
    CHART_MAX_STEP_SECONDS=int(os.environ.get("CHART_MAX_STEP_SECONDS",str(7*86400)))
    APP_PORT=int(os.environ.get("APP_PORT","8080"))
    APP_HOST=os.environ.get("APP_HOST","0.0.0.0")
    SECRET_KEY=os.environ.get("SECRET_KEY","ganti-dengan-random-string-yang-aman")
