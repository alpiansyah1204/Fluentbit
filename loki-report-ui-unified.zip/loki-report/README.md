# Loki Report UI

## Revisi terbaru
### 1. Halaman Pencarian + Laporan digabung jadi SATU halaman
Sebelumnya ada 2 halaman terpisah (`/` dan `/report`) dengan filter sendiri-sendiri.
Sekarang hanya ada **satu halaman** (`/`) yang punya:
- filter label (cascading)
- pencarian kata di isi log
- quick range (1 Jam / 6 Jam / 24 Jam / 7 Hari / 30 Hari / 90 Hari) + custom Start/End
- tombol **Cari** (menampilkan tabel log + grafik sekaligus, dengan filter yang sama)
- tombol **Export CSV**
- tombol **Download PDF Laporan**

Semua tombol itu memakai filter & rentang tanggal yang SAMA persis (tidak ada lagi filter yang beda-beda antar halaman). URL lama `/report` otomatis diarahkan ke `/`.

### 2. Value tiap dropdown benar-benar mengikuti filter yang sudah dipilih
Contoh: pilih `os = windows` -> dropdown `host`, `server_role`, dll otomatis hanya berisi server Windows. Ini berlaku untuk semua label (`app_group`, `environment`, `host`, `ip`, `job`, `os`, `server_role`, `service_name`, `site`, `source`).

Implementasi cascading diperkuat: semua dropdown diambil ulang **secara bersamaan** dari satu snapshot filter yang sama, lalu diterapkan sekaligus. Ini menghindari kemungkinan hasil dropdown tidak konsisten tergantung urutan pemrosesan.

Filter yang sama juga dipakai untuk tabel hasil pencarian, grafik, CSV, dan PDF — jadi begitu memilih `os = windows`, keempatnya (tabel, grafik, CSV, PDF) otomatis hanya berisi data Windows.

### 3. Perbaikan grafik ("chart error" saat pilih tanggal)
Ditemukan 2 penyebab:
- **Resolusi grafik tetap (per hari)** walau rentang tanggal yang dipilih pendek (mis. 1 Jam), sehingga grafik sering tampak kosong/rusak. Sekarang resolusi grafik **otomatis menyesuaikan panjang rentang**:
  - ≤ 6 jam → per 5 menit
  - ≤ 2 hari → per jam
  - ≤ 45 hari → per hari
  - lebih dari itu → per minggu
- **Ukuran kanvas grafik tidak dikunci**, sehingga Chart.js bisa "melar"/rusak tampilannya setiap kali data di-refresh berulang kali (ganti tanggal berkali-kali). Sekarang grafik dibungkus wrapper dengan tinggi tetap, dan chart lama selalu di-destroy sebelum yang baru dibuat.
- Tanggal Start/End kosong atau Start ≥ End sekarang divalidasi di sisi form (pesan error jelas) sebelum request dikirim, jadi tidak ada lagi error tak terduga di grafik.

### 4. Report PDF & CSV tetap memakai custom time range
Tetap bisa menentukan:
- tanggal + jam START/END, atau quick range
- seluruh filter label
- text search

PDF berisi **record log aktual** pada range tersebut (bukan hanya total/contoh).

## PDF dan batas record
PDF mengambil halaman-halaman log sampai range habis atau mencapai:
`REPORT_MAX_LOG_LINES=50000`

Jika batas tercapai, PDF menampilkan warning sehingga pengguna tahu bahwa hasil belum lengkap. Untuk laporan lengkap gunakan range/filter yang lebih sempit atau naikkan `REPORT_MAX_LOG_LINES`.

## Install/update
Copy project ke `/opt/loki-report-ui`, lalu:
```bash
source venv/bin/activate
pip install -r requirements.txt
python -m py_compile app.py
systemctl restart loki-report-ui
systemctl status loki-report-ui --no-pager
```

Jika menggunakan `.env`, contoh:
```env
LOKI_URL=http://192.168.114.75:3100
APP_PORT=8080
MAX_LOG_LINES=2000
REPORT_MAX_LOG_LINES=50000
LOKI_TIMEOUT=60
CHART_MIN_STEP_SECONDS=60
CHART_MAX_STEP_SECONDS=604800
```

## Test
```bash
curl http://192.168.114.75:3100/ready
curl http://127.0.0.1:8080/api/health
```
