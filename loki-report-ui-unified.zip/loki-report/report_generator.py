import csv,io
from datetime import datetime
from collections import defaultdict
from reportlab.lib.pagesizes import A4,landscape
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate,Table,TableStyle,Paragraph,Spacer,PageBreak
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.pdfbase.pdfmetrics import stringWidth

def logs_to_csv(lines):
    buf=io.StringIO();writer=csv.writer(buf)
    keys=sorted({k for x in lines for k in x.get("labels",{}).keys()})
    writer.writerow(["timestamp"]+keys+["log_line"])
    for x in lines:
        ts=datetime.fromtimestamp(x["timestamp_ns"]/1e9).strftime("%Y-%m-%d %H:%M:%S")
        writer.writerow([ts]+[x["labels"].get(k,"") for k in keys]+[x["line"]])
    out=io.BytesIO(buf.getvalue().encode("utf-8-sig"));out.seek(0);return out

def _bucket_format(step_seconds):
    """Pilih format label bucket waktu sesuai resolusi step grafik."""
    if step_seconds>=86400:return "%Y-%m-%d"
    if step_seconds>=3600:return "%Y-%m-%d %H:00"
    return "%Y-%m-%d %H:%M"

def _daily_counts_from_series(series,step_seconds=86400):
    """
    Kumpulkan hasil count_over_time menjadi bucket waktu berurutan.
    step_seconds menentukan granularitas label (hari/jam/menit) sehingga
    rentang tanggal pendek (mis. 1 jam) tetap menghasilkan grafik yang
    bermakna, bukan grafik kosong.
    """
    fmt=_bucket_format(step_seconds)
    daily=defaultdict(int)
    for s in series:
        for p in s["points"]:
            bucket=datetime.fromtimestamp(p["timestamp"]).strftime(fmt)
            daily[bucket]+=int(p["value"])
    return dict(sorted(daily.items()))

def build_log_pdf(title,filters,period_label,lines,truncated,max_lines):
    buf=io.BytesIO()
    doc=SimpleDocTemplate(buf,pagesize=landscape(A4),
                          topMargin=1.1*cm,bottomMargin=1.1*cm,
                          leftMargin=1.0*cm,rightMargin=1.0*cm)
    styles=getSampleStyleSheet()
    title_style=ParagraphStyle("ReportTitle",parent=styles["Title"],fontSize=18,leading=21)
    small=ParagraphStyle("Small",parent=styles["Normal"],fontSize=7,leading=9)
    logstyle=ParagraphStyle("Log",parent=styles["Normal"],fontName="Courier",fontSize=6.5,leading=8)
    elements=[Paragraph(title,title_style),
              Paragraph(f"<b>Periode:</b> {period_label}",small),
              Paragraph(f"<b>Dibuat:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",small),
              Spacer(1,.2*cm)]
    ft=", ".join(f"{k}={v}" for k,v in filters.items() if v) or "Semua data OS"
    elements.append(Paragraph(f"<b>Filter:</b> {ft}",small))
    elements.append(Paragraph(f"<b>Record yang dimasukkan:</b> {len(lines):,}",small))
    if truncated:
        elements.append(Paragraph(
            f"<b>PERINGATAN:</b> hasil mencapai batas REPORT_MAX_LOG_LINES={max_lines:,}. "
            "PDF tidak memuat record setelah batas tersebut. Persempit range/filter untuk laporan lengkap.",
            ParagraphStyle("Warn",parent=small,textColor=colors.red)))
    elements.append(Spacer(1,.25*cm))
    if not lines:
        elements.append(Paragraph("Tidak ada log pada periode/filter yang dipilih.",styles["Normal"]))
    else:
        data=[["Waktu","Source","Host","IP","OS","Application","Log"]]
        for x in lines:
            l=x.get("labels",{})
            ts=datetime.fromtimestamp(x["timestamp_ns"]/1e9).strftime("%Y-%m-%d %H:%M:%S")
            data.append([ts,l.get("source",""),l.get("host",""),l.get("ip",""),
                         l.get("os",""),l.get("app_group",""),Paragraph(str(x["line"]).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;"),logstyle)])
        t=Table(data,colWidths=[3.0*cm,2.0*cm,3.2*cm,3.0*cm,1.7*cm,2.7*cm,9.0*cm],
                repeatRows=1)
        t.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1e40af")),
            ("TEXTCOLOR",(0,0),(-1,0),colors.white),
            ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
            ("FONTSIZE",(0,0),(-1,0),7),("FONTSIZE",(0,1),(-1,-1),6.5),
            ("GRID",(0,0),(-1,-1),.25,colors.grey),
            ("VALIGN",(0,0),(-1,-1),"TOP"),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#f8fafc")]),
            ("LEFTPADDING",(0,0),(-1,-1),3),("RIGHTPADDING",(0,0),(-1,-1),3),
            ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ]))
        elements.append(t)
    doc.build(elements)
    buf.seek(0);return buf
