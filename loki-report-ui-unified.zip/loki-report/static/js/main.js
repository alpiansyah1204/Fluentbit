async function fetchJSON(url){const res=await fetch(url);let data={};try{data=await res.json()}catch{}if(!res.ok)throw new Error(data.error||data.message||"Terjadi kesalahan");return data}
function escapeHtml(s){const d=document.createElement("div");d.textContent=s??"";return d.innerHTML}
function localInputDate(d){const p=n=>String(n).padStart(2,"0");return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`}
async function checkStatus(){const el=document.getElementById("loki-status");if(!el)return;try{const d=await fetchJSON("/api/health");el.textContent=d.loki_connected?"✅ Terhubung ke Loki":"⚠️ Loki tidak siap";el.className="status "+(d.loki_connected?"ok":"error")}catch{el.textContent="⚠️ Gagal cek status";el.className="status error"}}

/*
 * Cascading filter dropdowns.
 * Semua select diambil ulang SECARA BERSAMAAN dari satu snapshot nilai
 * form yang sama (bukan satu-per-satu berurutan), lalu diterapkan sekaligus
 * setelah semua request selesai. Ini memastikan setiap dropdown benar-benar
 * konsisten dengan kombinasi filter yang sedang aktif -- mis. begitu
 * os=windows dipilih, seluruh dropdown lain (host, server_role, dst) hanya
 * berisi nilai milik server Windows, tanpa efek urutan pemrosesan.
 */
async function populateCascading(prefix){
 const selects=[...document.querySelectorAll(`select[id^="${prefix}-"]`)];
 const snapshot={};selects.forEach(s=>snapshot[s.name]=s.value);
 selects.forEach(s=>s.disabled=true);
 const results=await Promise.all(selects.map(async sel=>{
   const params=new URLSearchParams();
   selects.forEach(other=>{if(other!==sel && snapshot[other.name])params.set(other.name,snapshot[other.name])});
   try{
     const d=await fetchJSON(`/api/label-values/${encodeURIComponent(sel.name)}?${params}`);
     return {sel,values:d.values||[],ok:true};
   }catch(e){console.warn("label",sel.name,e);return {sel,ok:false};}
 }));
 results.forEach(({sel,values,ok})=>{
   if(ok){
     const old=snapshot[sel.name];
     sel.innerHTML='<option value="">-- semua --</option>';
     values.forEach(v=>{const o=document.createElement("option");o.value=v;o.textContent=v;sel.appendChild(o)});
     sel.value=values.includes(old)?old:"";
   }
   sel.disabled=false;
 });
}
function initCascading(prefix){
 const selects=[...document.querySelectorAll(`select[id^="${prefix}-"]`)];
 selects.forEach(s=>s.addEventListener("change",()=>populateCascading(prefix)));
 populateCascading(prefix);
}

function renderLogs(lines,tbody,table,empty){
 tbody.innerHTML="";
 if(!lines.length){table.style.display="none";empty.style.display="block";return}
 table.style.display="table";empty.style.display="none";
 for(const item of lines){
   const tr=document.createElement("tr"),ts=new Date(item.timestamp_ns/1e6).toLocaleString("id-ID");
   const lh=Object.entries(item.labels||{}).map(([k,v])=>`<span class="badge">${escapeHtml(k)}=${escapeHtml(v)}</span>`).join("");
   tr.innerHTML=`<td class="ts">${ts}</td><td>${lh}</td><td class="line">${escapeHtml(item.line)}</td>`;
   tbody.appendChild(tr);
 }
}

function setRange(kind){
 const end=new Date(),start=new Date(end);
 const m={"1h":3600000,"6h":6*3600000,"24h":86400000,"7d":7*86400000,"30d":30*86400000,"90d":90*86400000};
 start.setTime(end.getTime()-(m[kind]||m["30d"]));
 document.getElementById("range-start").value=localInputDate(start);
 document.getElementById("range-end").value=localInputDate(end);
}

/* Bangun query params dari form + tanggal, dengan validasi supaya tidak
 * pernah melempar exception (mis. saat field tanggal kosong) yang bisa
 * membuat grafik "error" tanpa pesan yang jelas. */
function buildParams(form){
 const p=new URLSearchParams(new FormData(form));
 p.delete("start");p.delete("end");
 const startEl=document.getElementById("range-start"),endEl=document.getElementById("range-end");
 const startVal=startEl.value,endVal=endEl.value;
 if(!startVal||!endVal) throw new Error("Tentukan tanggal/jam Start dan End terlebih dahulu.");
 const start=new Date(startVal),end=new Date(endVal);
 if(isNaN(start.getTime())||isNaN(end.getTime())) throw new Error("Format tanggal/jam tidak valid.");
 if(start>=end) throw new Error("Tanggal Start harus sebelum End.");
 p.set("start",start.toISOString());p.set("end",end.toISOString());
 return p;
}

function initPage(){
 const form=document.getElementById("search-form");if(!form)return;
 initCascading("filter");
 const table=document.getElementById("result-table"),tbody=document.getElementById("result-body"),
       empty=document.getElementById("empty-state"),info=document.getElementById("search-info");
 const toolbar=document.getElementById("quick-range-toolbar");
 let chart=null;

 function setActiveQuickRange(btn){
  toolbar.querySelectorAll(".quick-range").forEach(b=>b.classList.remove("active"));
  if(btn)btn.classList.add("active");
 }
 toolbar.querySelectorAll(".quick-range").forEach(b=>b.addEventListener("click",()=>{
   setRange(b.dataset.range);setActiveQuickRange(b);runSearch();
 }));
 // Kalau user mengubah tanggal secara manual, itu jadi rentang custom (tidak ada tombol quick range yang aktif).
 ["range-start","range-end"].forEach(id=>document.getElementById(id).addEventListener("change",()=>setActiveQuickRange(null)));

 async function updateChart(params){
  const chartWrap=document.getElementById("dailyChart");
  try{
    const d=await fetchJSON(`/api/report/monthly-chart-data?${params}`);
    if(chart){chart.destroy();chart=null}
    chart=new Chart(chartWrap,{type:"bar",
      data:{labels:d.labels,datasets:[{label:"Jumlah Log",data:d.values,backgroundColor:"#2563eb"}]},
      options:{responsive:true,maintainAspectRatio:false,animation:false,
        plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}});
    return d;
  }catch(e){
    if(chart){chart.destroy();chart=null}
    throw e;
  }
 }

 async function runSearch(){
  info.textContent="Mencari log aktual...";
  let params;
  try{params=buildParams(form)}catch(e){info.textContent="Error: "+e.message;return}
  try{
   const [s,d]=await Promise.all([
     fetchJSON(`/api/search?${params}`),
     updateChart(params)
   ]);
   renderLogs(s.lines,tbody,table,empty);
   info.textContent=`${s.count.toLocaleString("id-ID")} record dikembalikan • ${d.total.toLocaleString("id-ID")} total pada grafik • ${s.start} → ${s.end}`;
  }catch(e){info.textContent="Error: "+e.message}
 }

 form.addEventListener("submit",e=>{e.preventDefault();runSearch()});
 document.getElementById("btn-export-csv").addEventListener("click",()=>{
   let params;try{params=buildParams(form)}catch(e){info.textContent="Error: "+e.message;return}
   location.href=`/api/export/csv?${params}`;
 });
 document.getElementById("btn-download-pdf").addEventListener("click",()=>{
   let params;try{params=buildParams(form)}catch(e){info.textContent="Error: "+e.message;return}
   location.href=`/api/report/monthly-pdf?${params}`;
 });

 setRange("30d");
 runSearch();
}

document.addEventListener("DOMContentLoaded",()=>{checkStatus();initPage()});
