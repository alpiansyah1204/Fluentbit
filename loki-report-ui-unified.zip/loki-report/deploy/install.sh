#!/usr/bin/env bash
# Script bantu instalasi Loki Report UI di RHEL/CentOS/Rocky/Alma.
# Jalankan sebagai root: sudo bash deploy/install.sh
set -e

APP_DIR="/opt/loki-report-ui"
SERVICE_USER="loki-ui"

echo ">> [1/6] Cek Python3"
if command -v python3 >/dev/null 2>&1; then
    echo "   Python3 sudah ada: $(python3 --version) di $(command -v python3) -- lewati instalasi."
else
    echo "   Python3 belum ditemukan, mencoba install via dnf/yum..."
    if command -v dnf >/dev/null 2>&1; then
        dnf install -y python3 python3-pip
    else
        yum install -y python3 python3-pip
    fi
fi

echo ">> Cek modul venv (bawaan Python3, biasanya tidak perlu paket terpisah di RHEL)"
if ! python3 -m venv --help >/dev/null 2>&1; then
    echo "   Modul venv belum tersedia, mencoba install python3-pip (kadang venv ikut di dalamnya)..."
    if command -v dnf >/dev/null 2>&1; then
        dnf install -y python3-pip || true
    else
        yum install -y python3-pip || true
    fi
    if ! python3 -m venv --help >/dev/null 2>&1; then
        echo "   GAGAL: 'python3 -m venv' masih tidak jalan."
        echo "   Kemungkinan server ini tidak ada akses internet/repo yum belum dikonfigurasi."
        echo "   Solusi manual: minta admin repo lokal (satellite/local mirror), atau gunakan"
        echo "   'pip3 install virtualenv' lalu ganti perintah 'python3 -m venv' di bawah dengan 'virtualenv'."
        exit 1
    fi
fi

echo ">> Cek firewalld (opsional, dilewati kalau tidak ada / tidak dipakai)"
if ! command -v firewall-cmd >/dev/null 2>&1; then
    echo "   firewalld tidak terpasang, coba install (boleh gagal jika tanpa internet)..."
    if command -v dnf >/dev/null 2>&1; then
        dnf install -y firewalld || echo "   Lewati: firewalld tidak berhasil diinstall, atur port terbuka secara manual."
    else
        yum install -y firewalld || echo "   Lewati: firewalld tidak berhasil diinstall, atur port terbuka secara manual."
    fi
fi

echo ">> [2/6] Membuat user service khusus (tanpa login shell)"
if ! id "$SERVICE_USER" &>/dev/null; then
    useradd --system --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER"
fi

echo ">> [3/6] Menyalin aplikasi ke $APP_DIR"
mkdir -p "$APP_DIR"
# Skrip ini diasumsikan dijalankan dari dalam folder project (hasil unzip)
cp -r ./* "$APP_DIR"/
cp .env.example "$APP_DIR"/.env 2>/dev/null || true

echo ">> [4/6] Membuat virtualenv & install dependency"
cd "$APP_DIR"
python3 -m venv venv
"$APP_DIR"/venv/bin/pip install --upgrade pip
"$APP_DIR"/venv/bin/pip install -r requirements.txt

echo ">> [5/6] Set permission"
chown -R "$SERVICE_USER":"$SERVICE_USER" "$APP_DIR"

echo ">> [6/6] Pasang systemd service"
cp deploy/loki-report-ui.service /etc/systemd/system/loki-report-ui.service
systemctl daemon-reload
systemctl enable --now loki-report-ui

echo ">> Membuka port 8080 di firewalld (jika tersedia)"
if command -v firewall-cmd >/dev/null 2>&1; then
    systemctl enable --now firewalld || true
    firewall-cmd --permanent --add-port=8080/tcp || true
    firewall-cmd --reload || true
else
    echo "   firewalld tidak tersedia -- lewati. Buka port 8080 manual jika perlu (mis. iptables)."
fi

echo ""
echo "=== SELESAI ==="
echo "Cek status   : systemctl status loki-report-ui"
echo "Lihat log    : journalctl -u loki-report-ui -f"
echo "Akses web di : http://$(hostname -I | awk '{print $1}'):8080"
