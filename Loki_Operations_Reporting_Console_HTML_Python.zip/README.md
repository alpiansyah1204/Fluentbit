# Loki Operations & Reporting Console

HTML/CSS/JavaScript frontend + Python FastAPI backend.

## Install
```bash
cd /data/log_management
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Run
```bash
python3 app.py
```
Open `http://<server-ip>:8500`.

Default Loki: `http://192.168.114.75` (Nginx :80).

## Features
- Operations overview
- Total server / online / no-heartbeat
- Application/server distribution
- Site, OS, role, environment reports
- Log source distribution
- Heartbeat-derived server inventory
- Full Log Explorer
- Free LogQL Query Console
- Loki label/value browser
- CSV exports
- Loki health diagnostics
- Read-only Loki access

Heartbeat is `source="heartbeat"`, inventory is 30d, online is 5m, and heartbeat is excluded from OS log statistics.

## Troubleshooting
```bash
python3 -m py_compile app.py
pip check
curl -v http://192.168.114.75/ready
curl -G http://192.168.114.75/loki/api/v1/query   --data-urlencode 'query=count(sum by (host) (count_over_time({job="os-logs",source="heartbeat"}[5m])))'
tail -f logs/app.log
```

## systemd
Create `/etc/systemd/system/loki-log-console.service`:
```ini
[Unit]
Description=Loki Operations Reporting Console
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=loki-report
Group=loki-report
WorkingDirectory=/data/log_management
Environment=LOKI_URL=http://192.168.114.75
Environment=APP_PORT=8500
ExecStart=/data/log_management/venv/bin/python /data/log_management/app.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```
Then:
```bash
systemctl daemon-reload
systemctl enable --now loki-log-console
systemctl status loki-log-console --no-pager
journalctl -u loki-log-console -f
```

"No heartbeat" means the agent/reporting path has not been observed recently; it is not absolute proof that the OS is powered off.
