from datetime import datetime, timedelta, timezone
from pathlib import Path
import csv, io, logging, os, re, time
from typing import Optional

import requests
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

BASE_DIR=Path(__file__).resolve().parent
(BASE_DIR/"logs").mkdir(exist_ok=True)
(BASE_DIR/"reports").mkdir(exist_ok=True)

LOKI_URL=os.getenv("LOKI_URL","http://192.168.114.75").rstrip("/")
LOKI_TIMEOUT=int(os.getenv("LOKI_TIMEOUT","30"))
APP_HOST=os.getenv("APP_HOST","0.0.0.0")
APP_PORT=int(os.getenv("APP_PORT","8500"))
HEARTBEAT_WINDOW=os.getenv("HEARTBEAT_WINDOW","5m")
INVENTORY_WINDOW=os.getenv("INVENTORY_WINDOW","30d")

logging.basicConfig(filename=str(BASE_DIR/"logs/app.log"),level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
log=logging.getLogger("loki-console")

app=FastAPI(title="Loki Operations & Reporting Console",version="1.0.0")
app.mount("/static",StaticFiles(directory=str(BASE_DIR/"static")),name="static")
templates=Jinja2Templates(directory=str(BASE_DIR/"templates"))

class QueryRequest(BaseModel):
    query:str=Field(min_length=1,max_length=20000)
    query_type:str="range"
    start:Optional[str]=None
    end:Optional[str]=None
    limit:int=Field(5000,ge=1,le=100000)

class ReportRequest(BaseModel):
    start:str
    end:str
    environment:str="All"
    site:str="All"
    os:str="All"
    server_role:str="All"
    app_group:str=""
    host:str=""
    ip:str=""

def now(): return datetime.now(timezone.utc)
def dt(v,default):
    if not v:return default
    v=v.strip()
    if v.endswith("Z"):v=v[:-1]+"+00:00"
    x=datetime.fromisoformat(v)
    return (x if x.tzinfo else x.replace(tzinfo=timezone.utc)).astimezone(timezone.utc)
def ns(x):return str(int(x.timestamp()*1e9))
def esc(v):return v.strip().replace("\\","\\\\").replace('"','\\"')

def loki(path,params=None):
    url=LOKI_URL+path;t=time.perf_counter()
    try:
        r=requests.get(url,params=params or {},timeout=LOKI_TIMEOUT)
        elapsed=time.perf_counter()-t
        try:data=r.json()
        except:data={"raw":r.text}
        log.info("GET %s status=%s %.3fs",r.url,r.status_code,elapsed)
        if not r.ok:raise HTTPException(502,detail={"message":"Loki HTTP error","status":r.status_code,"response":data})
        return {"data":data,"elapsed":elapsed,"url":r.url}
    except HTTPException:raise
    except requests.RequestException as e:
        log.exception("Loki connection error")
        raise HTTPException(502,detail={"message":"Cannot connect to Loki","error":str(e),"url":url})

def selector(f,hb=None):
    p=['job="os-logs"']
    for k in ["environment","site","os","server_role","app_group","host","ip"]:
        v=f.get(k,"")
        if v and v!="All":p.append(f'{k}=~"{esc(v)}"')
    if hb is True:p.append('source="heartbeat"')
    if hb is False:p.append('source!="heartbeat"')
    return "{"+",".join(p)+"}"

def metric(q):return loki("/loki/api/v1/query",{"query":q})
def rng(q,s,e,limit):return loki("/loki/api/v1/query_range",{"query":q,"start":ns(s),"end":ns(e),"limit":limit,"direction":"backward"})
def rows(payload):
    out=[]
    for x in payload.get("data",{}).get("result",[]):
        r=dict(x.get("metric",{}));v=x.get("value",[])
        if v:r.update(timestamp=v[0],value=v[1])
        out.append(r)
    return out
def streams(payload):
    out=[]
    for x in payload.get("data",{}).get("result",[]):
        labels=x.get("stream",{})
        for v in x.get("values",[]):
            if len(v)>1:
                r=dict(labels);r.update(timestamp_ns=v[0],log=v[1]);out.append(r)
    return out
def val(p):
    a=p.get("data",{}).get("result",[])
    try:return float(a[0]["value"][1]) if a else 0
    except:return 0
def unique(stream,label,window):
    return f'count by ({label}) (sum by (host,{label}) (count_over_time({stream}[{window}])))'
def uhosts(stream,window):
    return f'count(sum by (host) (count_over_time({stream}[{window}])))'

def queries(req):
    f=req.model_dump();hb=selector(f,True);lg=selector(f,False)
    s=dt(req.start,now()-timedelta(hours=6));e=dt(req.end,now())
    sec=max(1,int((e-s).total_seconds()))
    return {
      "total_servers":uhosts(hb,INVENTORY_WINDOW),
      "online_servers":uhosts(hb,HEARTBEAT_WINDOW),
      "total_applications":f'count(sum by (app_group) (count_over_time({hb}[{INVENTORY_WINDOW}])))',
      "total_ips":f'count(sum by (ip) (count_over_time({hb}[{INVENTORY_WINDOW}])))',
      "total_logs":f'sum(count_over_time({lg}[{sec}s]))',
      "applications":unique(hb,"app_group",INVENTORY_WINDOW),
      "sites":unique(hb,"site",INVENTORY_WINDOW),
      "oses":unique(hb,"os",INVENTORY_WINDOW),
      "roles":unique(hb,"server_role",INVENTORY_WINDOW),
      "environments":unique(hb,"environment",INVENTORY_WINDOW),
      "sources":f'sum by (source) (count_over_time({lg}[{sec}s]))',
      "inventory":f'sum by (host,ip,os,environment,app_group,server_role,site) (count_over_time({hb}[{INVENTORY_WINDOW}]))'
    }

@app.get("/",response_class=HTMLResponse)
def index(request:Request):
    return templates.TemplateResponse("index.html",{"request":request,"loki_url":LOKI_URL})

@app.get("/api/health")
def health():
    t=time.perf_counter()
    try:
        r=requests.get(LOKI_URL+"/ready",timeout=10)
        return {"ok":r.ok,"status_code":r.status_code,"text":r.text.strip(),
                "latency_ms":round((time.perf_counter()-t)*1000,1),"loki_url":LOKI_URL}
    except Exception as e:
        return {"ok":False,"status_code":None,"text":str(e),
                "latency_ms":round((time.perf_counter()-t)*1000,1),"loki_url":LOKI_URL}

@app.get("/api/labels")
def labels():return loki("/loki/api/v1/labels")

@app.get("/api/labels/{label}/values")
def label_values(label:str):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*",label):
        raise HTTPException(400,"Invalid label")
    return loki(f"/loki/api/v1/label/{label}/values")

@app.post("/api/query")
def query(req:QueryRequest):
    if req.query_type=="instant":
        r=metric(req.query);r["result_rows"]=rows(r["data"]);return r
    e=dt(req.end,now());s=dt(req.start,e-timedelta(hours=6))
    if s>=e:raise HTTPException(400,"Start must be before end")
    r=rng(req.query,s,e,req.limit);r["result_rows"]=streams(r["data"]);return r

@app.post("/api/report")
def report(req:ReportRequest):
    q=queries(req);out={"queries":q,"metrics":{}}
    for k in ["total_servers","online_servers","total_applications","total_ips","total_logs"]:
        try:r=metric(q[k]);out["metrics"][k]={"value":val(r["data"]),"query":q[k],"latency_ms":round(r["elapsed"]*1000,1)}
        except HTTPException as e:out["metrics"][k]={"value":None,"query":q[k],"error":e.detail}
    for k in ["applications","sites","oses","roles","environments","sources","inventory"]:
        try:out[k]=rows(metric(q[k])["data"])
        except HTTPException:out[k]=[]
    out["generated_at"]=now().isoformat()
    return out

@app.post("/api/logs")
def logs(req:QueryRequest):
    e=dt(req.end,now());s=dt(req.start,e-timedelta(hours=1))
    r=rng(req.query,s,e,req.limit);x=streams(r["data"])
    return {"ok":True,"count":len(x),"elapsed_ms":round(r["elapsed"]*1000,1),"rows":x}

@app.get("/api/export/logs")
def export_logs(query:str=Query(...),start:str=Query(...),end:str=Query(...),limit:int=Query(50000,ge=1,le=100000)):
    r=rng(query,dt(start,now()-timedelta(hours=1)),dt(end,now()),limit);x=streams(r["data"])
    fields=["timestamp_ns","host","ip","os","environment","app_group","server_role","site","source","log"]
    s=io.StringIO();w=csv.DictWriter(s,fieldnames=fields,extrasaction="ignore");w.writeheader();w.writerows(x)
    return StreamingResponse(iter([s.getvalue().encode()]),media_type="text/csv",
      headers={"Content-Disposition":'attachment; filename="loki_logs.csv"'})

if __name__=="__main__":
    import uvicorn
    uvicorn.run("app:app",host=APP_HOST,port=APP_PORT,reload=False)
