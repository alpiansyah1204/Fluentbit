
import csv,io,html
from datetime import datetime,timezone
from reportlab.lib.pagesizes import A4,landscape
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak
def fmt_ns(ns):
    return datetime.fromtimestamp(ns/1e9,timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
def logs_csv(lines):
    keys=sorted({k for x in lines for k in x["labels"]})
    s=io.StringIO(); w=csv.writer(s)
    w.writerow(["timestamp"]+keys+["log"])
    for x in lines:w.writerow([fmt_ns(x["timestamp_ns"])]+[x["labels"].get(k,"") for k in keys]+[x["line"]])
    b=io.BytesIO(s.getvalue().encode("utf-8-sig"));b.seek(0);return b
def build_pdf(title,start,end,filters,query,lines,truncated=False):
    b=io.BytesIO()
    doc=SimpleDocTemplate(b,pagesize=landscape(A4),leftMargin=8*mm,rightMargin=8*mm,topMargin=8*mm,bottomMargin=8*mm)
    st=getSampleStyleSheet()
    small=ParagraphStyle("small",parent=st["Normal"],fontSize=6.5,leading=8)
    tiny=ParagraphStyle("tiny",parent=st["Normal"],fontSize=5.5,leading=7)
    elems=[Paragraph(title,st["Title"]),Paragraph(f"Period: {start} → {end}",st["Normal"]),
           Paragraph("Filters: "+(", ".join(f"{k}={v}" for k,v in filters.items() if v) or "All OS logs"),small),
           Paragraph("LogQL: "+html.escape(query),tiny),Spacer(1,4*mm),
           Paragraph(f"Actual log records included: {len(lines):,}"+(" (REPORT LIMIT REACHED)" if truncated else ""),st["Heading3"])]
    data=[["Timestamp","Source","Host","IP","Application","OS","Role","Site","Log"]]
    for x in lines:
        l=x["labels"]; msg=str(x["line"])
        data.append([fmt_ns(x["timestamp_ns"]),l.get("source",""),l.get("host",""),l.get("ip",""),
                     l.get("app_group",""),l.get("os",""),l.get("server_role",""),l.get("site",""),
                     Paragraph(html.escape(msg),tiny)])
    t=Table(data,colWidths=[27*mm,17*mm,30*mm,27*mm,25*mm,15*mm,20*mm,15*mm,75*mm],repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1e3a8a")),
      ("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTSIZE",(0,0),(-1,0),6),
      ("GRID",(0,0),(-1,-1),.2,colors.grey),("VALIGN",(0,0),(-1,-1),"TOP"),
      ("FONTSIZE",(0,1),(-1,-1),5.5)]))
    elems.append(t);doc.build(elems);b.seek(0);return b
