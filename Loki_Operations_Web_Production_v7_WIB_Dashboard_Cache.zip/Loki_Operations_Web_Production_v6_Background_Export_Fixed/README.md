# Loki Operations Web v6

Fixes:
- Quick Range disables START/END; Custom enables them.
- Filter values load asynchronously in the background; the page is not blocked by Loki filter discovery.
- Filter option results use a short server-side TTL cache.
- CSV and PDF exports fetch in Loki-safe chunks of <= 5000 entries per query, avoiding `max_entries_limit` errors.
- Browser downloads use fetch/blob and show API errors in the page instead of navigating to a JSON error page.
- Loki is still accessed server-side; browser never calls Loki :3100 directly.
- Existing `.env` is preserved by deploy/install.sh.
