let servers=[],currentRows=[],nextCursor=null,filterTimer=null;
const filterSeq={x:0,r:0};
const $=id=>document.getElementById(id);

// Central API client. All browser requests to the Flask Web UI go through this function.
// Loki itself is contacted server-side by Flask; the browser never calls Loki:3100 directly.
async function api(url, options={}) {
  const response = await fetch(url, {
    cache: "no-store",
    ...options,
    headers: {
      "Accept": "application/json",
      ...(options.headers || {})
    }
  });
  const contentType = response.headers.get("content-type") || "";
  let data;
  if (contentType.includes("application/json")) {
    data = await response.json();
  } else {
    const text = await response.text();
    data = { ok: false, error: text || `HTTP ${response.status}` };
  }
  if (!response.ok || data?.ok === false) {
    throw new Error(data?.error || data?.message || `HTTP ${response.status}`);
  }
  return data;
}
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;",'\'':"&#39;"}[c]));
function local(d){let p=n=>String(n).padStart(2,"0");return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`}
function initDates(p){let e=new Date(),s=new Date(e);s.setDate(s.getDate()-30);if($(`${p}-start`))$(`${p}-start`).value=local(s);if($(`${p}-end`))$(`${p}-end`).value=local(e)}
function params(p){
  let q=new URLSearchParams();
  document.querySelectorAll(`.cascade[data-prefix="${p}"]`).forEach(x=>{if(x.value)q.set(x.dataset.label,x.value)});
  let text=$(`${p}-q`)?.value.trim();if(text)q.set("q",text);
  let rangeEl=$(`${p}-range`);if(!rangeEl)throw Error(`Page filter control is missing: ${p}-range`);
  let range=rangeEl.value;
  if(range!=="custom")q.set("range",range);
  else{
    let start=$(`${p}-start`)?.value,end=$(`${p}-end`)?.value;
    if(!start||!end)throw Error("Custom range requires both START and END.");
    let s=new Date(start),e=new Date(end);
    if(Number.isNaN(s.getTime())||Number.isNaN(e.getTime()))throw Error("Invalid START/END date-time.");
    if(s>=e)throw Error("START must be earlier than END.");
    q.set("start",s.toISOString());q.set("end",e.toISOString());
  }
  return q;
}
function applyFilterOptions(p,options){
  for(let s of document.querySelectorAll(`.cascade[data-prefix="${p}"]`)){
    let old=s.value,vals=options?.[s.dataset.label]||[];
    s.innerHTML='<option value="">-- ALL --</option>'+vals.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join("");
    if(vals.includes(old))s.value=old;
  }
}
async function refreshFilters(p){
  let seq=++filterSeq[p],q;
  try{q=params(p)}catch(e){console.warn(e);return}
  let status=$(`${p}-filter-info`);if(status)status.textContent="Loading filter values…";
  try{
    let d=await api("/api/filter-options?"+q);
    if(seq!==filterSeq[p])return;
    if(!d.ok)throw Error(d.error||"Unable to load filters");
    applyFilterOptions(p,d.options);
    if(status)status.textContent=`${Object.values(d.options||{}).reduce((n,a)=>n+a.length,0).toLocaleString()} available filter values • ${d.latency_ms} ms`;
  }catch(e){
    if(status)status.textContent="Filter load error: "+e.message;
    console.warn(e);
  }
}
function setRangeState(p){
  const r=$(`${p}-range`), s=$(`${p}-start`), e=$(`${p}-end`);
  const custom=r && r.value==="custom";
  if(s) { s.disabled=!custom; s.title=custom?"Enter custom start date-time":"Select Custom to enable"; }
  if(e) { e.disabled=!custom; e.title=custom?"Enter custom end date-time":"Select Custom to enable"; }
}
function initFilters(p){
  if($(`${p}-range`)?.dataset.initialized==="1")return;
  initDates(p); setRangeState(p);
  document.querySelectorAll(`.cascade[data-prefix="${p}"]`).forEach(s=>s.addEventListener("change",()=>{
    clearTimeout(filterTimer);filterTimer=setTimeout(()=>refreshFilters(p),100);
  }));
  $(`${p}-range`)?.addEventListener("change",()=>{setRangeState(p);refreshFilters(p);});
  $(`${p}-start`)?.addEventListener("change",()=>{if($(`${p}-range`)?.value==="custom")refreshFilters(p)});
  $(`${p}-end`)?.addEventListener("change",()=>{if($(`${p}-range`)?.value==="custom")refreshFilters(p)});
  if($(`${p}-range`))$(`${p}-range`).dataset.initialized="1";
}

async function bootFilters(p){
  // Non-blocking startup: render the page immediately and load Loki filter values in the background.
  initFilters(p);
  const status=$(`${p}-filter-info`);
  if(status) status.textContent="Loading filter values in background…";
  try{
    const d=await api("/api/bootstrap?range=30d");
    if(!d.ok||!d.loki_connected) throw Error(d.error||"Loki is not ready");
    applyFilterOptions(p,d.options);
    if(status) status.textContent=`${Object.values(d.options||{}).reduce((n,a)=>n+a.length,0).toLocaleString()} available filter values • ${d.filter_latency_ms} ms`;
  }catch(e){
    if(status) status.textContent="Filter load error: "+e.message+" • Retry";
    console.warn("Background filter load failed",e);
  }
}

function renderLogs(lines,id){
  if(!lines.length){$(id).innerHTML='<div class="empty">No log records found.</div>';return}
  $(id).innerHTML='<table><thead><tr><th>TIME (WIB)</th><th>SOURCE</th><th>HOST</th><th>IP</th><th>APPLICATION</th><th>OS</th><th>ROLE</th><th>LOG</th></tr></thead><tbody>'+lines.map(x=>{
    let l=x.labels||{};
    let t=new Date(x.timestamp_ns/1e6).toLocaleString("en-GB",{timeZone:"Asia/Jakarta",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false});
    return `<tr><td>${esc(t)}</td><td>${esc(l.source)}</td><td>${esc(l.host)}</td><td>${esc(l.ip)}</td><td>${esc(l.app_group)}</td><td>${esc(l.os)}</td><td>${esc(l.server_role)}</td><td class="line">${esc(x.line)}</td></tr>`
  }).join('')+'</tbody></table>'
}
async function searchLogs(append=false){let p="x",q;try{q=params(p)}catch(e){$("x-info").textContent="ERROR: "+e.message;return}if(append&&nextCursor)q.set("cursor",nextCursor);$("x-info").textContent="Loading actual logs…";try{let d=await api("/api/search?"+q);currentRows=append?currentRows.concat(d.lines):d.lines;nextCursor=d.next_cursor;$("x-query").textContent=d.query;$("x-info").textContent=`${currentRows.length.toLocaleString()} records loaded • ${d.latency_ms} ms${d.has_more?" • more available":""}`;renderLogs(currentRows,"x-results");$("x-more").style.display=d.has_more?"inline-block":"none"}catch(e){$("x-info").textContent="ERROR: "+e.message}}
function loadMore(){searchLogs(true)}
function resetFilters(p){document.querySelectorAll(`.cascade[data-prefix="${p}"]`).forEach(x=>x.value="");if($(`${p}-q`))$(`${p}-q`).value="";if($(`${p}-range`))$(`${p}-range`).value="30d";initDates(p);refreshFilters(p);if(p==="x"){$("x-results").innerHTML='<div class="empty">Filters reset.</div>';$('x-query').textContent="";$('x-info').textContent=""}}
async function downloadFile(url,infoId,fallbackName){
  const info=$(infoId); if(info) info.textContent="Preparing download…";
  try{
    const r=await fetch(url,{cache:"no-store",headers:{"Accept":"application/octet-stream,application/pdf,text/csv,application/json"}});
    if(!r.ok){
      let msg=`HTTP ${r.status}`;
      const ct=r.headers.get("content-type")||"";
      try{ const d=ct.includes("json")?await r.json():await r.text(); msg=d?.error||d?.message||d||msg; }catch{}
      throw Error(msg);
    }
    const blob=await r.blob();
    let name=fallbackName;
    const cd=r.headers.get("content-disposition")||"";
    const m=cd.match(/filename[^;=]*=(?:UTF-8''|\")?([^;\"]+)/i);
    if(m) name=decodeURIComponent(m[1].replace(/\"/g,""));
    const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(a.href),1000);
    if(info) info.textContent="Download ready.";
  }catch(e){if(info) info.textContent="ERROR: "+e.message;}
}
async function exportLogs(p){try{await downloadFile("/api/export/csv?"+params(p),p+"-info","loki_logs.csv")}catch(e){$(p+"-info").textContent="ERROR: "+e.message}}
async function reportPreview(){let p="r",q;try{q=params(p)}catch(e){$("r-info").textContent="ERROR: "+e.message;return}$('r-info').textContent="Loading actual logs…";try{let d=await api("/api/report/preview?"+q);$("r-query").textContent=d.query;$("r-info").textContent=`${d.count.toLocaleString()} records in preview • ${d.latency_ms} ms${d.truncated?" • preview limit reached":""}`;renderLogs(d.lines,"r-results")}catch(e){$("r-info").textContent="ERROR: "+e.message}}
async function downloadPDF(){try{await downloadFile("/api/report/pdf?"+params("r"),"r-info","loki_os_report.pdf")}catch(e){$("r-info").textContent="ERROR: "+e.message}}
async function loadInventory(){try{let d=await api("/api/inventory");servers=d.servers||[];$("inv-info").textContent=`${servers.length} servers`;renderInventory()}catch(e){$("inv-info").textContent="ERROR: "+e.message}}
function renderInventory(){let q=($("inv-search").value||"").toLowerCase(),a=servers.filter(x=>JSON.stringify(x).toLowerCase().includes(q));$("inv-table").innerHTML='<table><thead><tr><th>HOST</th><th>IP</th><th>APP GROUP</th><th>OS</th><th>ROLE</th><th>ENV</th><th>SITE</th><th>STATUS</th></tr></thead><tbody>'+a.map(x=>`<tr><td>${esc(x.host)}</td><td>${esc(x.ip)}</td><td>${esc(x.app_group)}</td><td>${esc(x.os)}</td><td>${esc(x.server_role)}</td><td>${esc(x.environment)}</td><td>${esc(x.site)}</td><td class="${x.online?"online":"offline"}">${x.online?"ONLINE":"NO HEARTBEAT"}</td></tr>`).join("")+'</tbody></table>'}
async function runLogQL(){try{let type=$("qt").value,s=new Date(Date.now()-3600000),e=new Date();let d=await api("/api/logql",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:$("qeditor").value,type,start:s.toISOString(),end:e.toISOString(),limit:5000})});$("qinfo").textContent=`${d.count??(d.data?.data?.result?.length||0)} result • ${d.latency_ms} ms`;if(type==="range")renderLogs(d.lines,"qresults");else $("qresults").innerHTML="<pre>"+esc(JSON.stringify(d.data,null,2))+"</pre>"}catch(e){$("qinfo").textContent="ERROR: "+e.message}}
function renderDashboard(d,source="live"){
  $("total").textContent=(d.total_servers??0).toLocaleString();
  $("online").textContent=(d.online??0).toLocaleString();
  $("offline").textContent=(d.offline??0).toLocaleString();
  $("logs").textContent=(d.logs_24h??0).toLocaleString();
  $("critical").textContent=(d.critical_24h??0).toLocaleString();
  const info=$("dashboard-info");
  if(info){const ts=d.generated_at?new Date(d.generated_at).toLocaleString("en-GB",{timeZone:"Asia/Jakarta",hour12:false}):"";info.textContent=source==="cache"?`Loaded from browser cache${ts?" • "+ts:""}`:`Loaded from Loki${ts?" • "+ts:""}`;}
  if($("status") && d.loki_connected!==false){$("status").textContent="● LOKI ONLINE";$("status").className="online";}
}
async function dashboard(force=false){
  const key="lokiDashboardCacheV1";
  if(!force){
    try{const raw=localStorage.getItem(key);if(raw){const cached=JSON.parse(raw);if(cached&&cached.data){renderDashboard(cached.data,"cache");return;}}}catch(e){console.warn("Dashboard cache read failed",e)}
  }
  const info=$("dashboard-info");if(info)info.textContent="Loading dashboard metrics in background…";
  try{
    const d=await api("/api/dashboard");
    renderDashboard(d,"live");
    try{localStorage.setItem(key,JSON.stringify({saved_at:Date.now(),data:d}));}catch(e){console.warn("Dashboard cache write failed",e)}
  }catch(e){if(info)info.textContent="Dashboard load error: "+e.message;console.warn(e)}
}
function refreshDashboard(){try{localStorage.removeItem("lokiDashboardCacheV1")}catch(e){}dashboard(true)}
async function health(){try{let d=await api("/api/health");$("status").textContent=d.loki_connected?"● LOKI ONLINE":"● LOKI OFFLINE";$("status").className=d.loki_connected?"online":"offline";if($("healthbox"))$("healthbox").innerHTML=`<h2>Loki</h2><p class="${d.loki_connected?"online":"offline"}">${d.loki_connected?"CONNECTED":"NOT CONNECTED"}</p><p>URL: ${esc(d.loki_url)}</p><p>Latency: ${d.latency_ms} ms</p><p>${esc(d.message)}</p>`}catch(e){}}
function bootPage(){
  const target=$("page-kind")?.dataset.page;
  if(target==="explorer"||target==="report")bootFilters(target==="explorer"?"x":"r");
}
document.addEventListener("DOMContentLoaded",()=>{
  if($("total")){
    // Dashboard metrics are cached in the browser. A normal page refresh renders
    // the cached snapshot immediately and does not call Loki again.
    dashboard(false);
  }else{
    health();
  }
  bootPage();
  if($("inv-table"))loadInventory();
})
