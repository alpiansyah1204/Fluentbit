#!/usr/bin/env bash
set -euo pipefail
APP_DIR=/opt/loki-report-ui
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
USER_NAME=loki-report
id "$USER_NAME" >/dev/null 2>&1 || useradd --system --home "$APP_DIR" --shell /sbin/nologin "$USER_NAME"
mkdir -p "$APP_DIR" "$APP_DIR/logs" "$APP_DIR/data"
cp -a "$SRC_DIR/." "$APP_DIR/"
cd "$APP_DIR"
python3 -m venv venv
venv/bin/pip install --upgrade pip
venv/bin/pip install -r requirements.txt
if [ ! -f .env ]; then cp .env.example .env; fi
mkdir -p logs data
chown -R "$USER_NAME:$USER_NAME" "$APP_DIR"
cp deploy/loki-report-ui.service /etc/systemd/system/loki-report-ui.service
systemctl daemon-reload
systemctl enable --now loki-report-ui
echo "Installed. Web UI: http://$(hostname -I | awk '{print $1}'):8080"
echo "Loki target: $(grep '^LOKI_URL=' .env)"
echo "Nginx existing configuration was NOT changed."
