
import os
from dotenv import load_dotenv
load_dotenv()
class Config:
    LOKI_URL=os.getenv("LOKI_URL","http://192.168.114.75:3100").rstrip("/")
    APP_HOST=os.getenv("APP_HOST","0.0.0.0")
    APP_PORT=int(os.getenv("APP_PORT","8080"))
    LOKI_TIMEOUT=int(os.getenv("LOKI_TIMEOUT","60"))
    MAX_LOG_LINES=int(os.getenv("MAX_LOG_LINES","5000"))
    MAX_EXPORT_LINES=int(os.getenv("MAX_EXPORT_LINES","100000"))
    REPORT_MAX_LINES=int(os.getenv("REPORT_MAX_LINES","50000"))
    INVENTORY_DAYS=int(os.getenv("INVENTORY_DAYS","30"))
    ONLINE_MINUTES=int(os.getenv("ONLINE_MINUTES","5"))
    FILTER_CACHE_SECONDS=int(os.getenv("FILTER_CACHE_SECONDS","15"))
    LOKI_LABELS=["app_group","environment","host","ip","os","server_role","service_name","site","source"]
    FIXED_LABELS=["job"]
    SECRET_KEY=os.getenv("SECRET_KEY","change-this-secret")
