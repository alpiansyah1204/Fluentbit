# Loki Report UI

Web UI sederhana (Python/Flask) untuk melihat & membuat laporan log dari **Grafana Loki**,
ditujukan untuk pengguna non-teknis (NKN/non-teknis) — cukup pilih filter dari dropdown,
tanpa perlu tahu syntax LogQL.

## Fitur
- Filter log berdasarkan label: `app_group`, `environment`, `host`, `ip`, `job`, `os`,
  `server_role`, `service_name`, `site`, `source` — dropdown otomatis terisi nilai dari Loki.
- Pencarian kata kunci di isi log.
- Rentang waktu cepat (1 jam / 24 jam / 7 hari / **30 hari**/ 90 hari) atau bulan tertentu.
- Export hasil pencarian ke **CSV**.
- Laporan bulanan berupa **grafik jumlah log per hari** + **download PDF** (ringkasan + tabel + contoh log).
- Indikator status koneksi ke Loki.

## Struktur Project
```
loki-report-ui/
├── app.py                  # Flask app & routing
├── loki_client.py          # Komunikasi ke Loki API
├── report_generator.py     # Pembuat CSV & PDF
├── config.py                # Konfigurasi (baca dari .env)
├── requirements.txt
├── .env.example
├── templates/               # Halaman HTML
├── static/                  # CSS & JS
└── deploy/
    ├── install.sh                      # Script instalasi otomatis RHEL
    ├── loki-report-ui.service          # Unit systemd
    └── nginx-loki-report-ui.conf       # Contoh reverse proxy (opsional)
```

Loki diasumsikan berjalan di **192.168.114.75** (port default `3100`), dan web app ini
akan dijalankan **di server yang sama** dengan Loki tersebut.

---

## CARA DEPLOY DI RHEL

Ada 2 cara: **otomatis** (pakai script) atau **manual** (langkah demi langkah).

### Opsi A — Otomatis (disarankan)

1. Upload/extract file zip project ini ke server RHEL, misalnya ke `/root/loki-report-ui`.
   ```bash
   unzip loki-report-ui.zip
   cd loki-report-ui
   ```
2. Jalankan script instalasi sebagai root:
   ```bash
   sudo bash deploy/install.sh
   ```
   Script ini akan otomatis:
   - Install Python3, pip, firewalld
   - Membuat user service `loki-ui` (tanpa akses login, lebih aman)
   - Copy aplikasi ke `/opt/loki-report-ui`
   - Membuat virtualenv & install semua dependency
   - Memasang & menjalankan service `systemd` bernama `loki-report-ui`
   - Membuka port `8080` di firewall

3. Cek statusnya:
   ```bash
   systemctl status loki-report-ui
   ```
4. Akses dari browser: `http://192.168.114.75:8080`

---

### Opsi B — Manual (langkah per langkah)

**1. Install Python & tools**
```bash
sudo dnf install -y python3 python3-pip python3-venv firewalld
```

**2. Copy project ke lokasi permanen**
```bash
sudo mkdir -p /opt/loki-report-ui
sudo cp -r ./* /opt/loki-report-ui/
cd /opt/loki-report-ui
```

**3. Buat virtual environment & install dependency**
```bash
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

**4. Siapkan file konfigurasi**
```bash
cp .env.example .env
nano .env   # sesuaikan LOKI_URL jika perlu, defaultnya sudah http://192.168.114.75:3100
```

**5. Test jalankan manual dulu (opsional, untuk memastikan tidak error)**
```bash
python app.py
# buka http://<ip-server>:8080 dari browser, Ctrl+C untuk stop setelah dicoba
```

**6. Buat user khusus untuk service (best practice keamanan)**
```bash
sudo useradd --system --no-create-home --shell /usr/sbin/nologin loki-ui
sudo chown -R loki-ui:loki-ui /opt/loki-report-ui
```

**7. Pasang sebagai systemd service (auto-start & auto-restart)**
```bash
sudo cp deploy/loki-report-ui.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now loki-report-ui
sudo systemctl status loki-report-ui
```

**8. Buka port di firewall**
```bash
sudo systemctl enable --now firewalld
sudo firewall-cmd --permanent --add-port=8080/tcp
sudo firewall-cmd --reload
```

**9. (Opsional) Pasang Nginx sebagai reverse proxy di port 80**
```bash
sudo dnf install -y nginx
sudo cp deploy/nginx-loki-report-ui.conf /etc/nginx/conf.d/loki-report-ui.conf
# edit server_name sesuai hostname/IP anda
sudo nginx -t
sudo systemctl enable --now nginx
sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --reload
```
Setelah ini web bisa diakses tanpa menyebut port 8080: `http://192.168.114.75`

---

## Perintah Operasional Sehari-hari

| Kebutuhan                     | Perintah                                      |
|--------------------------------|------------------------------------------------|
| Lihat status                   | `systemctl status loki-report-ui`             |
| Restart setelah update code    | `sudo systemctl restart loki-report-ui`       |
| Lihat log aplikasi (live)      | `journalctl -u loki-report-ui -f`             |
| Stop service                   | `sudo systemctl stop loki-report-ui`          |
| Update dependency               | `source venv/bin/activate && pip install -r requirements.txt` |

## Update Aplikasi ke Versi Baru
```bash
sudo systemctl stop loki-report-ui
# timpa file di /opt/loki-report-ui dengan versi baru (kecuali .env)
sudo systemctl start loki-report-ui
```

## Troubleshooting

- **Status "⚠️ Loki tidak merespon" di web**: cek `curl http://192.168.114.75:3100/ready`
  dari server yang sama. Jika gagal, cek service Loki (`systemctl status loki`) dan pastikan
  port 3100 tidak diblok firewall lokal (`sudo firewall-cmd --list-ports`).
- **Dropdown filter kosong**: berarti label tersebut belum pernah muncul di log yang tersimpan
  di Loki, atau nama label di Loki berbeda dengan yang didaftarkan di `config.py` (`LOKI_LABELS`).
  Sesuaikan daftar label di `config.py` dengan label asli yang dipakai di Promtail/agent Anda.
- **PDF laporan gagal / chart tidak muncul**: pastikan `matplotlib` & `reportlab` terinstall
  (`pip list | grep -E "matplotlib|reportlab"`).
- **Port 8080 sudah dipakai**: ganti `APP_PORT` di file `.env`, lalu restart service.

## Catatan Keamanan
- Aplikasi ini tidak memiliki login/autentikasi bawaan. Jika akan diakses lebih luas
  (bukan hanya jaringan internal terbatas), tambahkan autentikasi dasar di level Nginx
  (misal `auth_basic`) atau tambahkan modul login Flask (Flask-Login) sebelum dipakai produksi.
- Batasi akses port 8080/80 hanya dari jaringan kantor/VPN lewat firewall, bukan dibuka ke publik.
