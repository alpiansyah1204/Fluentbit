import time
from datetime import datetime, timedelta

from flask import Flask, render_template, request, jsonify, send_file

from config import Config
import loki_client
import report_generator

app = Flask(__name__)
app.config.from_object(Config)


def to_ns(dt: datetime) -> int:
    return int(dt.timestamp() * 1e9)


def parse_range(args):
    """
    Baca rentang waktu dari query string.
    Mendukung quick range (?range=30d) atau custom (?start=...&end=... format ISO).
    Default: 30 hari terakhir (untuk kebutuhan report bulanan).
    """
    quick = args.get("range")
    start_str = args.get("start")
    end_str = args.get("end")

    now = datetime.now()

    if start_str and end_str:
        start = datetime.fromisoformat(start_str)
        end = datetime.fromisoformat(end_str)
        return start, end

    mapping = {
        "1h": timedelta(hours=1),
        "24h": timedelta(hours=24),
        "7d": timedelta(days=7),
        "30d": timedelta(days=30),
        "90d": timedelta(days=90),
    }
    delta = mapping.get(quick, timedelta(days=30))
    return now - delta, now


@app.route("/")
def index():
    return render_template("index.html", labels=Config.LOKI_LABELS)


@app.route("/report")
def report_page():
    return render_template("report.html", labels=Config.LOKI_LABELS)


@app.route("/api/health")
def health():
    ok = loki_client.check_connection()
    return jsonify({"loki_connected": ok, "loki_url": Config.LOKI_URL})


@app.route("/api/label-values/<label_name>")
def api_label_values(label_name):
    if label_name not in Config.LOKI_LABELS:
        return jsonify({"error": "label tidak dikenal"}), 400
    try:
        values = loki_client.get_label_values(label_name)
        return jsonify({"label": label_name, "values": values})
    except loki_client.LokiError as e:
        return jsonify({"error": str(e)}), 502


def _filters_from_request(args_or_json):
    return {label: args_or_json.get(label, "").strip() for label in Config.LOKI_LABELS}


@app.route("/api/search", methods=["GET"])
def api_search():
    filters = _filters_from_request(request.args)
    freetext = request.args.get("q", "").strip()
    start, end = parse_range(request.args)

    query = loki_client.build_logql(filters, freetext)
    try:
        lines = loki_client.query_range(query, to_ns(start), to_ns(end))
    except loki_client.LokiError as e:
        return jsonify({"error": str(e)}), 502

    return jsonify({
        "query": query,
        "count": len(lines),
        "start": start.isoformat(),
        "end": end.isoformat(),
        "lines": lines[: Config.MAX_LOG_LINES],
    })


@app.route("/api/export/csv")
def export_csv():
    filters = _filters_from_request(request.args)
    freetext = request.args.get("q", "").strip()
    start, end = parse_range(request.args)

    query = loki_client.build_logql(filters, freetext)
    try:
        lines = loki_client.query_range(query, to_ns(start), to_ns(end))
    except loki_client.LokiError as e:
        return jsonify({"error": str(e)}), 502

    csv_buf = report_generator.logs_to_csv(lines)
    filename = f"logs_{start.strftime('%Y%m%d')}_{end.strftime('%Y%m%d')}.csv"
    return send_file(csv_buf, mimetype="text/csv", as_attachment=True, download_name=filename)


@app.route("/api/report/monthly-pdf")
def report_monthly_pdf():
    """
    Laporan bulanan: default 30 hari terakhir, atau bulan tertentu via ?month=YYYY-MM
    """
    filters = _filters_from_request(request.args)
    month_str = request.args.get("month")  # format YYYY-MM

    if month_str:
        year, month = map(int, month_str.split("-"))
        start = datetime(year, month, 1)
        if month == 12:
            end = datetime(year + 1, 1, 1)
        else:
            end = datetime(year, month + 1, 1)
        period_label = start.strftime("%B %Y")
    else:
        end = datetime.now()
        start = end - timedelta(days=30)
        period_label = f"{start.strftime('%Y-%m-%d')} s/d {end.strftime('%Y-%m-%d')}"

    query = loki_client.build_logql(filters)

    try:
        series = loki_client.query_count_over_time(query, to_ns(start), to_ns(end), step_seconds=86400)
        sample_lines = loki_client.query_range(query, to_ns(start), to_ns(end), limit=20)
    except loki_client.LokiError as e:
        return jsonify({"error": str(e)}), 502

    daily_counts = report_generator._daily_counts_from_series(series)
    total_logs = sum(daily_counts.values())

    pdf_buf = report_generator.build_monthly_pdf(
        title="Laporan Bulanan Log",
        filters=filters,
        period_label=period_label,
        total_logs=total_logs,
        daily_counts=daily_counts,
        sample_lines=sample_lines,
    )
    filename = f"laporan_log_{start.strftime('%Y%m')}.pdf"
    return send_file(pdf_buf, mimetype="application/pdf", as_attachment=True, download_name=filename)


@app.route("/api/report/monthly-chart-data")
def report_chart_data():
    """Data JSON untuk chart di halaman /report (dipakai Chart.js)."""
    filters = _filters_from_request(request.args)
    start, end = parse_range(request.args)
    query = loki_client.build_logql(filters)

    try:
        series = loki_client.query_count_over_time(query, to_ns(start), to_ns(end), step_seconds=86400)
    except loki_client.LokiError as e:
        return jsonify({"error": str(e)}), 502

    daily_counts = report_generator._daily_counts_from_series(series)
    return jsonify({
        "labels": list(daily_counts.keys()),
        "values": list(daily_counts.values()),
        "total": sum(daily_counts.values()),
    })


if __name__ == "__main__":
    app.run(host=Config.APP_HOST, port=Config.APP_PORT, debug=False)
