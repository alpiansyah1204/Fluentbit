#!/usr/bin/env bash
# Script bantu instalasi Loki Report UI di RHEL/CentOS/Rocky/Alma.
# Jalankan sebagai root: sudo bash deploy/install.sh
set -e

APP_DIR="/opt/loki-report-ui"
SERVICE_USER="loki-ui"

echo ">> [1/6] Install Python3 & pip (jika belum ada)"
if command -v dnf >/dev/null 2>&1; then
    dnf install -y python3 python3-pip python3-venv firewalld
else
    yum install -y python3 python3-pip firewalld
fi

echo ">> [2/6] Membuat user service khusus (tanpa login shell)"
if ! id "$SERVICE_USER" &>/dev/null; then
    useradd --system --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER"
fi

echo ">> [3/6] Menyalin aplikasi ke $APP_DIR"
mkdir -p "$APP_DIR"
# Skrip ini diasumsikan dijalankan dari dalam folder project (hasil unzip)
cp -r ./* "$APP_DIR"/
cp .env.example "$APP_DIR"/.env 2>/dev/null || true

echo ">> [4/6] Membuat virtualenv & install dependency"
cd "$APP_DIR"
python3 -m venv venv
"$APP_DIR"/venv/bin/pip install --upgrade pip
"$APP_DIR"/venv/bin/pip install -r requirements.txt

echo ">> [5/6] Set permission"
chown -R "$SERVICE_USER":"$SERVICE_USER" "$APP_DIR"

echo ">> [6/6] Pasang systemd service"
cp deploy/loki-report-ui.service /etc/systemd/system/loki-report-ui.service
systemctl daemon-reload
systemctl enable --now loki-report-ui

echo ">> Membuka port 8080 di firewalld"
systemctl enable --now firewalld || true
firewall-cmd --permanent --add-port=8080/tcp || true
firewall-cmd --reload || true

echo ""
echo "=== SELESAI ==="
echo "Cek status   : systemctl status loki-report-ui"
echo "Lihat log    : journalctl -u loki-report-ui -f"
echo "Akses web di : http://$(hostname -I | awk '{print $1}'):8080"
