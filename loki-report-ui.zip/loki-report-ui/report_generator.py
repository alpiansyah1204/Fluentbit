"""
report_generator.py
Membuat file laporan (CSV mentah & PDF ringkasan bulanan) dari data Loki.
"""
import csv
import io
from datetime import datetime
from collections import defaultdict

from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False


def logs_to_csv(lines: list) -> io.BytesIO:
    """Ubah list log (dari loki_client.query_range) menjadi file CSV in-memory."""
    buf = io.StringIO()
    writer = csv.writer(buf)

    label_keys = set()
    for item in lines:
        label_keys.update(item["labels"].keys())
    label_keys = sorted(label_keys)

    writer.writerow(["timestamp"] + label_keys + ["log_line"])
    for item in lines:
        ts = datetime.fromtimestamp(item["timestamp_ns"] / 1e9).strftime("%Y-%m-%d %H:%M:%S")
        row = [ts] + [item["labels"].get(k, "") for k in label_keys] + [item["line"]]
        writer.writerow(row)

    out = io.BytesIO(buf.getvalue().encode("utf-8-sig"))  # BOM biar Excel baca UTF-8 dgn benar
    out.seek(0)
    return out


def _daily_counts_from_series(series: list):
    """Gabungkan semua series count_over_time jadi total per hari (YYYY-MM-DD)."""
    daily = defaultdict(int)
    for s in series:
        for point in s["points"]:
            day = datetime.fromtimestamp(point["timestamp"]).strftime("%Y-%m-%d")
            daily[day] += int(point["value"])
    return dict(sorted(daily.items()))


def _make_chart_image(daily_counts: dict):
    if not HAS_MATPLOTLIB or not daily_counts:
        return None
    fig, ax = plt.subplots(figsize=(9, 3.2))
    days = list(daily_counts.keys())
    values = list(daily_counts.values())
    ax.bar(days, values, color="#2563eb")
    ax.set_title("Jumlah Log per Hari")
    ax.set_ylabel("Jumlah Log")
    ax.tick_params(axis="x", rotation=75, labelsize=6)
    fig.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    buf.seek(0)
    return buf


def build_monthly_pdf(title: str, filters: dict, period_label: str,
                       total_logs: int, daily_counts: dict, sample_lines: list) -> io.BytesIO:
    """Buat laporan PDF ringkasan bulanan."""
    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=landscape(A4),
        topMargin=1.5 * cm, bottomMargin=1.5 * cm,
        leftMargin=1.5 * cm, rightMargin=1.5 * cm,
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleBig", parent=styles["Title"], fontSize=18)
    normal = styles["Normal"]

    elements = []
    elements.append(Paragraph(title, title_style))
    elements.append(Paragraph(f"Periode: {period_label}", normal))
    elements.append(Paragraph(f"Dibuat: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", normal))
    elements.append(Spacer(1, 0.4 * cm))

    # Ringkasan filter yang dipakai
    filter_text = ", ".join(f"{k}={v}" for k, v in filters.items() if v) or "Semua data (tanpa filter)"
    elements.append(Paragraph(f"<b>Filter:</b> {filter_text}", normal))
    elements.append(Paragraph(f"<b>Total log:</b> {total_logs:,}", normal))
    elements.append(Spacer(1, 0.4 * cm))

    chart_buf = _make_chart_image(daily_counts)
    if chart_buf:
        elements.append(Image(chart_buf, width=24 * cm, height=8 * cm))
        elements.append(Spacer(1, 0.4 * cm))

    if daily_counts:
        table_data = [["Tanggal", "Jumlah Log"]]
        for day, count in daily_counts.items():
            table_data.append([day, f"{count:,}"])
        t = Table(table_data, colWidths=[6 * cm, 6 * cm])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2563eb")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f1f5f9")]),
        ]))
        elements.append(t)
        elements.append(Spacer(1, 0.4 * cm))

    if sample_lines:
        elements.append(Paragraph("<b>Contoh log terbaru (maks 20 baris):</b>", normal))
        sample_data = [["Waktu", "Log"]]
        for item in sample_lines[:20]:
            ts = datetime.fromtimestamp(item["timestamp_ns"] / 1e9).strftime("%Y-%m-%d %H:%M:%S")
            text = item["line"][:140] + ("..." if len(item["line"]) > 140 else "")
            sample_data.append([ts, text])
        t2 = Table(sample_data, colWidths=[3.5 * cm, 21 * cm])
        t2.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#334155")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 7),
            ("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]))
        elements.append(t2)

    doc.build(elements)
    buf.seek(0)
    return buf
