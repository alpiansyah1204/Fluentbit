"""
loki_client.py
Wrapper sederhana untuk memanggil Loki HTTP API.
Dokumentasi resmi: https://grafana.com/docs/loki/latest/reference/api/
"""
import requests
from config import Config


class LokiError(Exception):
    pass


def _base_url():
    return Config.LOKI_URL.rstrip("/")


def get_label_values(label_name: str):
    """Ambil semua nilai unik untuk 1 label, misal semua host yang pernah kirim log."""
    url = f"{_base_url()}/loki/api/v1/label/{label_name}/values"
    try:
        resp = requests.get(url, timeout=Config.LOKI_TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
        return sorted(data.get("data", []))
    except requests.RequestException as e:
        raise LokiError(f"Gagal mengambil label '{label_name}' dari Loki: {e}")


def build_logql(filters: dict, freetext: str = ""):
    """
    Bangun query LogQL dari filter label yang dipilih user di UI.
    filters contoh: {"host": "srv-01", "environment": "production"}
    """
    selectors = []
    for key, value in filters.items():
        if value:
            selectors.append(f'{key}="{value}"')

    if not selectors:
        # Loki wajib ada minimal 1 stream selector, kalau user tidak pilih
        # apapun kita pakai job=~".+" supaya menyapu semua job yang ada.
        selectors.append('job=~".+"')

    query = "{" + ", ".join(selectors) + "}"

    if freetext:
        # filter isi teks log (case-sensitive contains)
        escaped = freetext.replace('"', '\\"')
        query += f' |= "{escaped}"'

    return query


def query_range(query: str, start_ns: int, end_ns: int, limit: int = None, direction: str = "backward"):
    """Ambil log mentah sesuai query & rentang waktu (dalam nanodetik unix epoch)."""
    url = f"{_base_url()}/loki/api/v1/query_range"
    params = {
        "query": query,
        "start": start_ns,
        "end": end_ns,
        "limit": limit or Config.MAX_LOG_LINES,
        "direction": direction,
    }
    try:
        resp = requests.get(url, params=params, timeout=Config.LOKI_TIMEOUT)
        resp.raise_for_status()
        payload = resp.json()
    except requests.RequestException as e:
        raise LokiError(f"Gagal query ke Loki: {e}")

    lines = []
    for stream in payload.get("data", {}).get("result", []):
        labels = stream.get("stream", {})
        for ts, line in stream.get("values", []):
            lines.append({
                "timestamp_ns": int(ts),
                "line": line,
                "labels": labels,
            })

    # urutkan terbaru dulu
    lines.sort(key=lambda x: x["timestamp_ns"], reverse=True)
    return lines


def query_count_over_time(query: str, start_ns: int, end_ns: int, step_seconds: int = 3600):
    """
    Ambil jumlah log per interval waktu (dipakai untuk chart & report bulanan).
    Membungkus query asli dengan count_over_time(...)[step]
    """
    base_selector = query.split("|=")[0].strip()  # ambil stream selector saja
    range_query = f'count_over_time({base_selector}[{step_seconds}s])'

    url = f"{_base_url()}/loki/api/v1/query_range"
    params = {
        "query": range_query,
        "start": start_ns,
        "end": end_ns,
        "step": f"{step_seconds}s",
    }
    try:
        resp = requests.get(url, params=params, timeout=Config.LOKI_TIMEOUT)
        resp.raise_for_status()
        payload = resp.json()
    except requests.RequestException as e:
        raise LokiError(f"Gagal mengambil statistik dari Loki: {e}")

    series = []
    for result in payload.get("data", {}).get("result", []):
        labels = result.get("metric", {})
        points = [
            {"timestamp": int(float(ts)), "value": float(val)}
            for ts, val in result.get("values", [])
        ]
        series.append({"labels": labels, "points": points})

    return series


def check_connection():
    """Cek apakah Loki bisa dihubungi (dipakai endpoint /health)."""
    url = f"{_base_url()}/ready"
    try:
        resp = requests.get(url, timeout=5)
        return resp.status_code == 200
    except requests.RequestException:
        return False
