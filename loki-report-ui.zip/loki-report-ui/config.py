import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # URL Loki API. Default mengarah ke server Loki yang disebutkan.
    LOKI_URL = os.environ.get("LOKI_URL", "http://192.168.114.75:3100")

    # Label / metric yang bisa difilter oleh user dari UI.
    LOKI_LABELS = [
        "app_group",
        "environment",
        "host",
        "ip",
        "job",
        "os",
        "server_role",
        "service_name",
        "site",
        "source",
    ]

    # Batas maksimal baris log yang diambil sekali query (biar UI tidak berat)
    MAX_LOG_LINES = int(os.environ.get("MAX_LOG_LINES", 2000))

    # Timeout request ke Loki (detik)
    LOKI_TIMEOUT = int(os.environ.get("LOKI_TIMEOUT", 30))

    # Port web app
    APP_PORT = int(os.environ.get("APP_PORT", 8080))
    APP_HOST = os.environ.get("APP_HOST", "0.0.0.0")

    SECRET_KEY = os.environ.get("SECRET_KEY", "ganti-dengan-random-string-yang-aman")
