// ---------- Util ----------
async function fetchJSON(url) {
  const res = await fetch(url);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Terjadi kesalahan");
  return data;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ---------- Status koneksi Loki ----------
async function checkStatus() {
  const el = document.getElementById("loki-status");
  if (!el) return;
  try {
    const data = await fetchJSON("/api/health");
    if (data.loki_connected) {
      el.textContent = "✅ Terhubung ke Loki";
      el.className = "status ok";
    } else {
      el.textContent = "⚠️ Loki tidak merespon";
      el.className = "status error";
    }
  } catch (e) {
    el.textContent = "⚠️ Gagal cek status";
    el.className = "status error";
  }
}

// ---------- Isi dropdown label dari Loki ----------
async function populateSelect(selectEl, labelName) {
  try {
    const data = await fetchJSON(`/api/label-values/${labelName}`);
    for (const v of data.values) {
      const opt = document.createElement("option");
      opt.value = v;
      opt.textContent = v;
      selectEl.appendChild(opt);
    }
  } catch (e) {
    console.warn("Gagal load label", labelName, e);
  }
}

function initFilterSelects(prefix) {
  document.querySelectorAll(`select[id^="${prefix}-"]`).forEach((sel) => {
    const labelName = sel.name;
    populateSelect(sel, labelName);
  });
}

// ---------- Halaman pencarian ----------
function initSearchPage() {
  const form = document.getElementById("search-form");
  if (!form) return;

  initFilterSelects("filter");

  const table = document.getElementById("result-table");
  const tbody = document.getElementById("result-body");
  const emptyState = document.getElementById("empty-state");
  const info = document.getElementById("search-info");

  function currentParams() {
    return new URLSearchParams(new FormData(form));
  }

  async function doSearch() {
    info.textContent = "Mencari...";
    try {
      const params = currentParams();
      const data = await fetchJSON(`/api/search?${params.toString()}`);
      tbody.innerHTML = "";
      if (data.lines.length === 0) {
        table.style.display = "none";
        emptyState.style.display = "block";
        emptyState.textContent = "Tidak ada log ditemukan untuk filter ini.";
      } else {
        table.style.display = "table";
        emptyState.style.display = "none";
        for (const item of data.lines) {
          const tr = document.createElement("tr");
          const ts = new Date(item.timestamp_ns / 1e6).toLocaleString("id-ID");
          const labelsHtml = Object.entries(item.labels)
            .map(([k, v]) => `<span class="badge">${escapeHtml(k)}=${escapeHtml(v)}</span>`)
            .join("");
          tr.innerHTML = `
            <td class="ts">${ts}</td>
            <td>${labelsHtml}</td>
            <td class="line">${escapeHtml(item.line)}</td>`;
          tbody.appendChild(tr);
        }
      }
      info.textContent = `${data.count} baris log ditemukan (query: ${data.query})`;
    } catch (e) {
      info.textContent = "Error: " + e.message;
    }
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    doSearch();
  });

  document.getElementById("btn-export-csv").addEventListener("click", () => {
    const params = currentParams();
    window.location.href = `/api/export/csv?${params.toString()}`;
  });
}

// ---------- Halaman laporan bulanan ----------
function initReportPage() {
  const form = document.getElementById("report-form");
  if (!form) return;

  initFilterSelects("rfilter");

  const info = document.getElementById("report-info");
  let chartInstance = null;

  function currentParams() {
    return new URLSearchParams(new FormData(form));
  }

  async function loadChart() {
    info.textContent = "Memuat grafik...";
    try {
      const params = currentParams();
      const monthVal = form.month.value; // YYYY-MM
      const queryParams = new URLSearchParams();
      for (const [k, v] of params.entries()) {
        if (k !== "month" && v) queryParams.set(k, v);
      }
      if (monthVal) {
        const [y, m] = monthVal.split("-").map(Number);
        const start = new Date(y, m - 1, 1);
        const end = new Date(y, m, 1);
        queryParams.set("start", start.toISOString());
        queryParams.set("end", end.toISOString());
      } else {
        queryParams.set("range", "30d");
      }

      const data = await fetchJSON(`/api/report/monthly-chart-data?${queryParams.toString()}`);
      const ctx = document.getElementById("dailyChart");
      if (chartInstance) chartInstance.destroy();
      chartInstance = new Chart(ctx, {
        type: "bar",
        data: {
          labels: data.labels,
          datasets: [{
            label: "Jumlah Log per Hari",
            data: data.values,
            backgroundColor: "#2563eb",
          }],
        },
        options: {
          responsive: true,
          plugins: { legend: { display: false } },
          scales: { y: { beginAtZero: true } },
        },
      });
      info.textContent = `Total log pada periode ini: ${data.total.toLocaleString("id-ID")}`;
    } catch (e) {
      info.textContent = "Error: " + e.message;
    }
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    loadChart();
  });

  document.getElementById("btn-download-pdf").addEventListener("click", () => {
    const params = currentParams();
    window.location.href = `/api/report/monthly-pdf?${params.toString()}`;
  });

  // load grafik pertama kali dengan default 30 hari
  loadChart();
}

document.addEventListener("DOMContentLoaded", () => {
  checkStatus();
  initSearchPage();
  initReportPage();
});
