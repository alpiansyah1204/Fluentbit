
from flask import Flask,render_template,request,jsonify,send_file
from datetime import datetime,timedelta,timezone
from config import Config
import loki_client,report_generator,os,time,re,threading
app=Flask(__name__);app.secret_key=Config.SECRET_KEY;app.config.from_object(Config)
_filter_cache={}
_filter_cache_lock=threading.Lock()

def cached_filter_options(current,start_ns,end_ns):
    key=(tuple(sorted(current.items())),int(start_ns),int(end_ns))
    now=time.time()
    with _filter_cache_lock:
        hit=_filter_cache.get(key)
        if hit and now-hit[0] < Config.FILTER_CACHE_SECONDS:
            return hit[1], 0.0, True
    out,lat=loki_client.stream_filter_options(current,Config.LOKI_LABELS,start_ns,end_ns)
    with _filter_cache_lock:
        _filter_cache[key]=(now,out)
        if len(_filter_cache)>256:
            oldest=min(_filter_cache,key=lambda k:_filter_cache[k][0]);_filter_cache.pop(oldest,None)
    return out,lat,False
def to_ns(x): return int(x.timestamp()*1e9)
def parse_dt(s,default):
    if not s:return default
    try:
        if s.endswith("Z"):s=s[:-1]+"+00:00"
        x=datetime.fromisoformat(s)
        return (x if x.tzinfo else x.replace(tzinfo=timezone.utc)).astimezone(timezone.utc)
    except ValueError: raise ValueError("Invalid ISO datetime")
def range_args(a):
    now=datetime.now(timezone.utc); quick=a.get("range","30d")
    if a.get("start") and a.get("end"): return parse_dt(a["start"],now-timedelta(days=30)),parse_dt(a["end"],now)
    mp={"1h":timedelta(hours=1),"24h":timedelta(days=1),"7d":timedelta(days=7),"30d":timedelta(days=30),"90d":timedelta(days=90)}
    return now-mp.get(quick,timedelta(days=30)),now
def filters_from(a):
    return {k:a.get(k,"").strip() for k in Config.LOKI_LABELS if a.get(k,"").strip()}
def error(e): return jsonify({"ok":False,"error":str(e)}),502

@app.route("/")
def index(): return render_template("dashboard.html",labels=Config.LOKI_LABELS)
@app.route("/explorer")
def explorer(): return render_template("explorer.html",labels=Config.LOKI_LABELS)
@app.route("/report")
def report(): return render_template("report.html",labels=Config.LOKI_LABELS)
@app.route("/inventory")
def inventory(): return render_template("inventory.html")
@app.route("/logql")
def logql(): return render_template("logql.html")
@app.route("/health")
def health_page(): return render_template("health.html")

@app.get("/api/health")
def api_health():
    ok,lat,msg=loki_client.health()
    return jsonify({"loki_connected":ok,"latency_ms":round(lat,1),"message":msg,"loki_url":Config.LOKI_URL})

@app.get("/api/diagnostics")
def api_diagnostics():
    """Server-side connectivity diagnostics for Web UI -> Loki."""
    out = {"web_ui": {"host": request.host}, "loki_url": Config.LOKI_URL}
    try:
        ok, lat, msg = loki_client.health()
        out["ready"] = {"ok": ok, "latency_ms": round(lat, 1), "message": msg}
        if not ok:
            return jsonify({"ok": False, **out}), 502
        labels, lat2 = loki_client._get("/loki/api/v1/labels", {})
        out["labels"] = {"ok": True, "count": len(labels.get("data", [])), "latency_ms": round(lat2, 1), "values": labels.get("data", [])}
        start = datetime.now(timezone.utc) - timedelta(hours=1)
        end = datetime.now(timezone.utc)
        streams, lat3 = loki_client.series('{job="os-logs",source!="heartbeat",source!="security"}', to_ns(start), to_ns(end))
        out["series"] = {"ok": True, "count": len(streams), "latency_ms": round(lat3, 1)}
        return jsonify({"ok": True, **out})
    except Exception as e:
        return jsonify({"ok": False, **out, "error": str(e)}), 502

@app.get("/api/bootstrap")
def api_bootstrap():
    """Fast preflight for Explorer/Reporting.
    The browser calls this before revealing the page. It performs one Loki
    readiness check and one /series request, returning the initial filter set.
    """
    start_time=time.perf_counter()
    try:
        start,end=range_args(request.args)
        current=filters_from(request.args)
        ok,health_lat,msg=loki_client.health()
        if not ok:
            return jsonify({"ok":False,"stage":"health","error":msg,"loki_connected":False}),502
        out,series_lat,cache_hit=cached_filter_options(current,to_ns(start),to_ns(end))
        return jsonify({
            "ok":True,
            "loki_connected":True,
            "options":out,
            "filters":current,
            "range":{"start":start.isoformat(),"end":end.isoformat()},
            "health_latency_ms":round(health_lat,1),
            "filter_latency_ms":round(series_lat,1),
            "cache_hit":cache_hit,
            "latency_ms":round((time.perf_counter()-start_time)*1000,1)
        })
    except Exception as e:
        return error(e)

@app.get("/api/filter-options")
def filter_options():
    # One Loki /series call, then derive all dropdown values locally.
    # This is substantially faster than querying every label endpoint separately.
    start,end=range_args(request.args); current=filters_from(request.args)
    try:
        out,lat,cache_hit=cached_filter_options(current,to_ns(start),to_ns(end))
        return jsonify({"ok":True,"options":out,"filters":current,"latency_ms":round(lat,1),"cache_hit":cache_hit})
    except Exception as e:return error(e)

@app.get("/api/search")
def search():
    try:
        start,end=range_args(request.args);filters=filters_from(request.args);text=request.args.get("q","").strip()
        q=loki_client.build_logql(filters,text);limit=min(int(request.args.get("limit",Config.MAX_LOG_LINES)),Config.MAX_LOG_LINES)
        cursor=request.args.get("cursor")
        end_ns=int(cursor) if cursor else to_ns(end)
        lines,lat=loki_client.query_range(q,to_ns(start),end_ns,limit)
        oldest=min((x["timestamp_ns"] for x in lines),default=None)
        return jsonify({"ok":True,"query":q,"start":start.isoformat(),"end":end.isoformat(),
                        "count":len(lines),"latency_ms":round(lat,1),"lines":lines,
                        "next_cursor":str(oldest) if oldest else None,"has_more":len(lines)>=limit})
    except Exception as e:return error(e)


def query_all_chunks(query,start_ns,end_ns,max_lines,batch=5000):
    """Fetch a larger export/report safely when Loki max_entries_limit is 5000.
    Uses repeated query_range calls with a moving end timestamp.
    """
    batch=min(max(1,int(batch)),5000)
    rows=[]
    cursor_end=end_ns
    while len(rows)<max_lines and cursor_end>start_ns:
        take=min(batch,max_lines-len(rows))
        chunk, _ = loki_client.query_range(query,start_ns,cursor_end,take)
        if not chunk:
            break
        rows.extend(chunk)
        oldest=min(x["timestamp_ns"] for x in chunk)
        if len(chunk)<take:
            break
        # Move strictly before the oldest record so the next page cannot duplicate it.
        if oldest<=start_ns:
            break
        cursor_end=oldest-1
    # Defensive de-duplication in case Loki returns overlapping boundary records.
    seen=set(); out=[]
    for x in rows:
        key=(x.get("timestamp_ns"),x.get("line"),tuple(sorted((x.get("labels") or {}).items())))
        if key not in seen:
            seen.add(key); out.append(x)
    out.sort(key=lambda x:x["timestamp_ns"],reverse=True)
    return out

@app.get("/api/export/csv")
def export_csv():
    try:
        start,end=range_args(request.args);filters=filters_from(request.args);text=request.args.get("q","")
        q=loki_client.build_logql(filters,text)
        lines=query_all_chunks(q,to_ns(start),to_ns(end),Config.MAX_EXPORT_LINES)
        b=report_generator.logs_csv(lines)
        return send_file(b,mimetype="text/csv",as_attachment=True,download_name=f"loki_logs_{start:%Y%m%d_%H%M}_{end:%Y%m%d_%H%M}.csv")
    except Exception as e:return error(e)

@app.get("/api/report/preview")
def report_preview():
    try:
        start,end=range_args(request.args);filters=filters_from(request.args);text=request.args.get("q","")
        q=loki_client.build_logql(filters,text);limit=min(int(request.args.get("limit",1000)),Config.MAX_LOG_LINES)
        lines,lat=loki_client.query_range(q,to_ns(start),to_ns(end),limit)
        return jsonify({"ok":True,"query":q,"count":len(lines),"latency_ms":round(lat,1),
                        "truncated":len(lines)>=limit,"lines":lines})
    except Exception as e:return error(e)

@app.get("/api/report/pdf")
def report_pdf():
    try:
        start,end=range_args(request.args);filters=filters_from(request.args);text=request.args.get("q","")
        q=loki_client.build_logql(filters,text)
        lines=query_all_chunks(q,to_ns(start),to_ns(end),Config.REPORT_MAX_LINES)
        truncated=len(lines)>=Config.REPORT_MAX_LINES
        b=report_generator.build_pdf("Loki OS Log Report",start.isoformat(),end.isoformat(),filters,q,lines,truncated)
        return send_file(b,mimetype="application/pdf",as_attachment=True,download_name=f"loki_os_report_{start:%Y%m%d_%H%M}_{end:%Y%m%d_%H%M}.pdf")
    except Exception as e:return error(e)

@app.get("/api/inventory")
def api_inventory():
    try:
        end=datetime.now(timezone.utc);start=end-timedelta(days=Config.INVENTORY_DAYS)
        streams,_=loki_client.series('{job="os-logs",source="heartbeat"}',to_ns(start),to_ns(end))
        servers={}
        for s in streams:
            if s.get("host"):servers[(s.get("host"),s.get("ip",""))]=s
        online_q=f'sum by (host,ip) (count_over_time({{job="os-logs",source="heartbeat"}}[{Config.ONLINE_MINUTES}m]))'
        d,_=loki_client.metric(online_q);online=set()
        for r in d.get("data",{}).get("result",[]):
            m=r.get("metric",{})
            if m.get("host"):online.add((m.get("host"),m.get("ip","")))
        out=[]
        for key,s in sorted(servers.items()):
            z=dict(s);z["online"]=key in online;out.append(z)
        return jsonify({"ok":True,"count":len(out),"servers":out})
    except Exception as e:return error(e)

@app.get("/api/dashboard")
def dashboard():
    try:
        now=datetime.now(timezone.utc);h=timedelta(hours=24)
        streams,_=loki_client.series('{job="os-logs",source="heartbeat"}',to_ns(now-timedelta(days=30)),to_ns(now))
        servers={(s.get("host"),s.get("ip","")):s for s in streams if s.get("host")}
        online_q=f'sum by (host,ip) (count_over_time({{job="os-logs",source="heartbeat"}}[{Config.ONLINE_MINUTES}m]))'
        d,_=loki_client.metric(online_q);online={(x.get("metric",{}).get("host"),x.get("metric",{}).get("ip","")) for x in d.get("data",{}).get("result",[])}
        logq='{job="os-logs",source!="heartbeat",source!="security"}'
        totalq=f'sum(count_over_time({logq}[24h]))'
        errq=f'sum(count_over_time({logq} |~ "(?i)(error|failed|critical|fatal)"[24h]))'
        a,_=loki_client.metric(totalq);b,_=loki_client.metric(errq)
        def val(d):
            r=d.get("data",{}).get("result",[])
            return int(float(r[0].get("value",[0,0])[1])) if r else 0
        return jsonify({"ok":True,"total_servers":len(servers),"online":len(online),
                        "offline":max(0,len(servers)-len(online)),"logs_24h":val(a),"critical_24h":val(b)})
    except Exception as e:return error(e)

@app.post("/api/logql")
def api_logql():
    try:
        x=request.get_json(force=True);q=x.get("query","").strip();typ=x.get("type","range")
        if not q:raise ValueError("Query kosong")
        if typ=="instant":
            d,lat=loki_client.metric(q);return jsonify({"ok":True,"type":"instant","latency_ms":round(lat,1),"data":d})
        start=parse_dt(x.get("start"),datetime.now(timezone.utc)-timedelta(hours=1));end=parse_dt(x.get("end"),datetime.now(timezone.utc))
        lines,lat=loki_client.query_range(q,to_ns(start),to_ns(end),min(int(x.get("limit",5000)),Config.MAX_LOG_LINES))
        return jsonify({"ok":True,"type":"range","latency_ms":round(lat,1),"count":len(lines),"lines":lines,"data":None})
    except Exception as e:return error(e)

@app.get("/api/labels")
def api_labels():
    try:
        vals,_=loki_client._get("/loki/api/v1/labels",{})
        return jsonify({"labels":vals.get("data",[])})
    except Exception as e:return error(e)

@app.get("/api/label-values/<label>")
def api_label_values(label):
    if label not in Config.LOKI_LABELS:return jsonify({"error":"invalid label"}),400
    try:
        vals,_=loki_client.label_values(label);return jsonify({"values":vals})
    except Exception as e:return error(e)

if __name__=="__main__":
    app.run(host=Config.APP_HOST,port=Config.APP_PORT)
