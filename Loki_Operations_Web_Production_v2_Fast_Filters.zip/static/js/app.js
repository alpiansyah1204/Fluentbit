let servers=[],currentRows=[],nextCursor=null,filterTimer=null;
const $=id=>document.getElementById(id);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(u,o){let r=await fetch(u,o),t=await r.text(),d;try{d=JSON.parse(t)}catch{d={error:t}}if(!r.ok)throw Error(d.error||d.message||"HTTP "+r.status);return d}
function local(d){let p=n=>String(n).padStart(2,"0");return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`}
function initDates(p){let e=new Date(),s=new Date(e);s.setDate(s.getDate()-30);$(`${p}-start`).value=local(s);$(`${p}-end`).value=local(e)}
function params(p){let q=new URLSearchParams();document.querySelectorAll(`.cascade[data-prefix="${p}"]`).forEach(x=>{if(x.value)q.set(x.dataset.label,x.value)});let text=$(`${p}-q`)?.value.trim();if(text)q.set("q",text);let range=$(`${p}-range`).value;if(range!="custom")q.set("range",range);else{q.set("start",new Date($(`${p}-start`).value).toISOString());q.set("end",new Date($(`${p}-end`).value).toISOString())}return q}
async function refreshFilters(p,changed){let q=params(p);try{let d=await api("/api/filter-options?"+q);for(let s of document.querySelectorAll(`.cascade[data-prefix="${p}"]`)){
  let old=s.value,vals=d.options[s.dataset.label]||[];
  s.innerHTML='<option value="">-- ALL --</option>'+vals.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join("");
  if(vals.includes(old))s.value=old;
}}catch(e){console.warn(e)}}
function initFilters(p){
  initDates(p);
  document.querySelectorAll(`.cascade[data-prefix="${p}"]`).forEach(s=>s.addEventListener("change",()=>{
    clearTimeout(filterTimer);
    filterTimer=setTimeout(()=>refreshFilters(p,s),100);
  }));
  refreshFilters(p,null);
}
function renderLogs(lines,id){if(!lines.length){$(id).innerHTML='<div class="empty">No log records found.</div>';return}$(id).innerHTML='<table><thead><tr><th>TIME (UTC)</th><th>SOURCE</th><th>HOST</th><th>IP</th><th>APPLICATION</th><th>OS</th><th>ROLE</th><th>LOG</th></tr></thead><tbody>'+lines.map(x=>{let l=x.labels;return `<tr><td>${new Date(x.timestamp_ns/1e6).toISOString().replace("T"," ").replace("Z","")}</td><td>${esc(l.source)}</td><td>${esc(l.host)}</td><td>${esc(l.ip)}</td><td>${esc(l.app_group)}</td><td>${esc(l.os)}</td><td>${esc(l.server_role)}</td><td class="line">${esc(x.line)}</td></tr>`}).join("")+'</tbody></table>'}
async function searchLogs(append=false){let p="x",q=params(p);if(append&&nextCursor)q.set("cursor",nextCursor);$("x-info").textContent="Loading...";try{let d=await api("/api/search?"+q);currentRows=append?currentRows.concat(d.lines):d.lines;nextCursor=d.next_cursor;$("x-query").textContent=d.query;$("x-info").textContent=`${currentRows.length.toLocaleString()} records loaded • ${d.latency_ms} ms`;renderLogs(currentRows,"x-results");$("x-more").style.display=d.has_more?"inline-block":"none"}catch(e){$("x-info").textContent="ERROR: "+e.message}}
function loadMore(){searchLogs(true)}
function resetFilters(p){document.querySelectorAll(`.cascade[data-prefix="${p}"]`).forEach(x=>x.value="");$(`${p}-q`).value="";$(`${p}-range`).value="30d";initDates(p);refreshFilters(p);if(p=="x"){$("x-results").innerHTML='<div class="empty">Filters reset.</div>'}}
function exportLogs(p){location.href="/api/export/csv?"+params(p)}
async function reportPreview(){let p="r",q=params(p);$("r-info").textContent="Loading actual logs...";try{let d=await api("/api/report/preview?"+q);$("r-query").textContent=d.query;$("r-info").textContent=`${d.count.toLocaleString()} records in preview • ${d.latency_ms} ms`;renderLogs(d.lines,"r-results")}catch(e){$("r-info").textContent="ERROR: "+e.message}}
function downloadPDF(){location.href="/api/report/pdf?"+params("r")}
async function loadInventory(){try{let d=await api("/api/inventory");servers=d.servers||[];$("inv-info").textContent=`${servers.length} servers`;renderInventory()}catch(e){$("inv-info").textContent="ERROR: "+e.message}}
function renderInventory(){let q=($("inv-search").value||"").toLowerCase(),a=servers.filter(x=>JSON.stringify(x).toLowerCase().includes(q));$("inv-table").innerHTML='<table><thead><tr><th>HOST</th><th>IP</th><th>APP GROUP</th><th>OS</th><th>ROLE</th><th>ENV</th><th>SITE</th><th>STATUS</th></tr></thead><tbody>'+a.map(x=>`<tr><td>${esc(x.host)}</td><td>${esc(x.ip)}</td><td>${esc(x.app_group)}</td><td>${esc(x.os)}</td><td>${esc(x.server_role)}</td><td>${esc(x.environment)}</td><td>${esc(x.site)}</td><td class="${x.online?"online":"offline"}">${x.online?"ONLINE":"NO HEARTBEAT"}</td></tr>`).join("")+'</tbody></table>'}
async function runLogQL(){try{let type=$("qt").value,s=new Date(Date.now()-3600000),e=new Date();let d=await api("/api/logql",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:$("qeditor").value,type,start:s.toISOString(),end:e.toISOString(),limit:5000})});$("qinfo").textContent=`${d.count??(d.data?.data?.result?.length||0)} result • ${d.latency_ms} ms`;if(type=="range")renderLogs(d.lines,"qresults");else $("qresults").innerHTML="<pre>"+esc(JSON.stringify(d.data,null,2))+"</pre>"}catch(e){$("qinfo").textContent="ERROR: "+e.message}}
async function dashboard(){try{let d=await api("/api/dashboard");$("total").textContent=d.total_servers.toLocaleString();$("online").textContent=d.online.toLocaleString();$("offline").textContent=d.offline.toLocaleString();$("logs").textContent=d.logs_24h.toLocaleString();$("critical").textContent=d.critical_24h.toLocaleString()}catch(e){console.warn(e)}}
async function health(){try{let d=await api("/api/health");$("status").textContent=d.loki_connected?"● LOKI ONLINE":"● LOKI OFFLINE";$("status").className=d.loki_connected?"online":"offline";if($("healthbox"))$("healthbox").innerHTML=`<h2>Loki</h2><p class="${d.loki_connected?"online":"offline"}">${d.loki_connected?"CONNECTED":"NOT CONNECTED"}</p><p>URL: ${esc(d.loki_url)}</p><p>Latency: ${d.latency_ms} ms</p><p>${esc(d.message)}</p>`}catch(e){}}
document.addEventListener("DOMContentLoaded",()=>{health();if($("total"))dashboard();if($("server")){}if($("x-range"))initFilters("x");if($("r-range"))initFilters("r");if($("inv-table"))loadInventory()})